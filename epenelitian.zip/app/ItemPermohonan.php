<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemPermohonan extends Model
{
    // public $timestamps = false;
    protected $table = 'item_permohonan';
    protected $primaryKey = 'id_item_permohonan';
}
