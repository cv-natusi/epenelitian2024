<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Identitas extends Model
{
  protected $table='identitas';
  protected $primaryKey='id_identitas';
  public $timestamps=false;
}
