<?php

namespace App\Http\Controllers\Owner;

use Illuminate\Http\Request;

class DocPendukungController extends Controller
{
    //
}
