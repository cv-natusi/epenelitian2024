<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Dalam Perbaikan - Silakan kembali lagi nanti</title>
  <meta name="description" content="Dalam Perbaikan - Silakan kembali lagi nanti">
  <meta name="author" content="Vamsi">
   	 	<link href='//fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>

<style>
     html {
      background: #f1f1f1;
     }
     body {
      background: #fff;
      max-width: 70%;
      font-family: "Open Sans", sans-serif;
      font-size: 14px;
      padding: 1.5em 2em;
      margin: 5em auto;
      -webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.13);
      box-shadow: 0 1px 3px rgba(0,0,0,0.13);
     }
  </style>
</head>
<body>
<h1>Dalam Perbaikan - Silakan kembali lagi nanti</h1>
Kami sedang melakukan update dan maintenance.
Silakan kembali lagi nanti
</body>
</html>