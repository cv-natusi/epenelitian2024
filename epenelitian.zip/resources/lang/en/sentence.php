<?php

// sentence.php

return [
  'welcome' => 'Welcome Friend'
];