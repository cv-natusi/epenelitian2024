<?php

// sentence.php

return [
  'welcome' => 'Selamat Datang'
];