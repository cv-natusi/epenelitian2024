<?php
return [
    'title' =>  'Localization Exmaple',
    'Username' => 'Nama User',
    'Password' => 'Kata Sandi'
];
?>