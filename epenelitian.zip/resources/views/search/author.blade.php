@extends('layout.main')
@section('content')
<div class="col-lg-12 col-md-12">
    <h1>Browse Author Index</h1>

</div>
@endsection