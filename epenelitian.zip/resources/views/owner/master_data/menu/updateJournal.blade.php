    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="panel panel-primary">
          <div class="panel-heading">
            {{$title}}
          </div>
        </div>
      </div>
    </div>

    