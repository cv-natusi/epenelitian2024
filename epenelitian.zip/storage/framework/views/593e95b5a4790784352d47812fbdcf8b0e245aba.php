<div class="modal fade" id="detail-dialog" tabindex="-1" role="dialog" aria-labelledby="product-detail-dialog">
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">
      <div class="modal-header" style="width: 100%">
          All Author Details
        <span style="float:right"><a data-dismiss="modal">Close</a></span>
      </div>
      <div class="modal-body">
        <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
          <h4 style="font-weight: bold; color: #4682B4;">Author Submission</h4>
          <hr style="  border: 1px solid DimGray;">
          <table class="table">
            <tbody>
            <?php if(!empty($submission->author_submit)): ?>
              <?php $__currentLoopData = $submission->author_submit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th>first Name</th>
                  <td> : <?php echo e($aut->first_name); ?></td>           
                </tr>
                <tr>
                  <th>Email</th>
                  <td> : <?php echo e($aut->email); ?></td>            
                </tr>
                <tr>
                  <th>Orcid ID</th>
                  <td> : <?php echo e($aut->id_orcid); ?></td>            
                </tr>
                <tr>
                  <th>Affiliation</th>
                  <td> : <?php echo e($aut->affiliation); ?></td>            
                </tr>
                <tr>
                  <th>Interest</th>
                  <td> : <?php echo $aut->interest; ?></td>           
                </tr>
                <tr>
                  <th>Bio</th>
                  <td> : <?php echo $aut->bio; ?></td>            
                </tr>
                <tr>
                  <td colspan="2">
                  <hr style="  border: 1px solid DimGray;">                              
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
          </table>

          <h4 style="font-weight: bold; color: #4682B4;">Supplementary File</h4>
          <hr style="  border: 1px solid DimGray;">
          <table class="table">
            <tbody>
                <?php if(!empty($submission->supplementary)): ?>
                  <?php $__currentLoopData = $submission->supplementary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th>Title</th>
                    <td> : <?php echo e($sup->title); ?></td>           
                  </tr>
                  <tr>
                    <th>File</th>
                    <td> : <?php echo e($sup->file); ?></td>            
                  </tr>
                  <tr>
                    <th>Creator</th>
                    <td> : <?php echo e($sup->creator); ?></td>            
                  </tr>
                  <tr>
                    <th>Type</th>
                    <td> : <?php echo e($sup->type); ?></td>            
                  </tr>
                  <tr>
                    <th>Descriptions</th>
                    <td> : <?php echo e($sup->description); ?></td>           
                  </tr>  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                <?php endif; ?>                      
            </tbody>
          </table>

          <h4 style="font-weight: bold; color: #4682B4;">Details Reviewers</h4>
          <hr style="  border: 1px solid DimGray;">
          <table class="table">
            <tbody>
                <?php if(!empty($submission->reviewer)): ?>
                  <?php $__currentLoopData = $submission->reviewer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th>USER ID</th>
                    <td> : <?php echo e($rev->users_id); ?></td>           
                  </tr>
                   <tr>
                    <th>First Name</th>
                    <td> : <?php echo e($rev->first_name); ?></td>           
                  </tr>
                  <tr>
                    <th>File</th>
                    <td> : <?php echo e($rev->file_sub); ?></td>            
                  </tr>
                  <tr>
                    <th>Description</th>
                    <td> : <?php echo e($rev->description); ?></td>            
                  </tr>
                  <tr>
                    <td colspan="2">
                    <hr style="  border: 1px solid DimGray;">                              
                    </td>
                  </tr>                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                <?php endif; ?>                      
            </tbody>
          </table>

        </div>
      </div>
      <div class="clearfix" style='padding-bottom:20px'></div>
    </div>
  </div>
</div>      
<script type="text/javascript">
  var onLoad = (function() {
    $('#detail-dialog').find('.modal-dialog').css({
        'width'     : '60%'
      });
    $('#detail-dialog').modal('show');
  })();
  $('#detail-dialog').on('hidden.bs.modal', function () {
    $('.modal-dialog').html('');
  })

  $.validator.setDefaults({
    submitHandler: function() {
      var data = $('#commentForm').serialize();
      $.post("<?php echo e(route('simpan_menu_owner')); ?>",data,function(data){
        if(data.status=='success'){
          window.location = "<?php echo e(url('/')); ?>/owner/data_master/menu";
        }else{
          swal('Tidak bisa disimpan');
        }
      });
    }
  });

  $().ready(function() {
    // validate the comment form when it is submitted
    $("#commentForm").validate();
  });
</script>
      