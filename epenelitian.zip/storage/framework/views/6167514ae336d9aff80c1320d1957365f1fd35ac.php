<?php $__env->startSection('content'); ?>
  <div class="col-lg-12 col-md-12 tbRes">
    <form action="<?php echo e(route('simpan_hasil_penelitian')); ?>" method="post" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <a href="<?php echo e(url('userhome')); ?>" class="btn btn-info" style="float: right;"><i class="fa fa-backward">  Back</i></a>
      <h3 style="font-weight: bold;">Upload hasil penelitian</h3>
      <h5>Detail Permohonan Penelitian</h5>
      <input type="hidden" name="id_permohonan" value="<?php echo e($permohonan->id_permohonan); ?>">
      <table class="table table-bordered">
        <tr>
          <td width="20%" style="font-weight: bold">Julud Penelitian</td>
          <td>:</td>
          <td width="30%"><?php echo e($permohonan->judul_penelitian); ?></td>
          <td width="20%" style="font-weight: bold">Nama Peneliti</td>
          <td>:</td>
          <td width="30%"><?php echo e($permohonan->first_name); ?> <?php echo e(($permohonan->middle_name!=null) ? $permohonan->middle_name : ''); ?> <?php echo e($permohonan->last_name); ?></td>
        </tr>
        <tr>
          <td width="20%" style="font-weight: bold">Tempat Penelitian</td>
          <td>:</td>                      
          <td width="30%">
              <ol>
              <?php $__currentLoopData = $verifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($temp->nama_tempat_penelitian); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ol>
          </td>
          <td width="20%" style="font-weight: bold">Unit Kerja</td>
          <td>:</td>
          <?php if($permohonan->unit_kerja != ''): ?>
          <td width="30%"><?php echo e($permohonan->unit_kerja); ?></td>
          <?php else: ?>
          <td width="30%"><?php echo e($permohonan->unit_instansi); ?></td>
          <?php endif; ?>
        </tr>
        <tr>
          <td width="20%" style="font-weight: bold">Waktu Penelitian</td>
          <td>:</td>
          <td width="30%"><?php echo e($permohonan->tgl_awal); ?> <b>sampai</b> <?php echo e($permohonan->tgl_akhir); ?></td>
          <td width="20%" style="font-weight: bold">No Identitas</td>
          <td>:</td>
          <td width="30%"><?php echo e($permohonan->no_identitas); ?></td>
        </tr>
      </table>

      <div class="col-lg-12 col-md-12">
        <h3>Abstrak</h3>
        <?php if($permohonan->status_hasil=='Diterima Admin' || $permohonan->status_hasil=='Publish'): ?>
          <?php echo (!empty($hasil)) ? $hasil->abstrak : ''; ?>

        <?php else: ?>
          <textarea class="form-control" value="" id="summary-ckeditor" name="abstrak" required=""> <?php echo e((!empty($hasil)) ? $hasil->abstrak : ''); ?> </textarea>
        <?php endif; ?>
        <h3>File yang harus diupload</h3>
        <?php
        $berkas_required = [];
        ?>
        <?php $__currentLoopData = $jenis_hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="form-group">
            <label class="col-lg-4 col-md-4"><?php echo e($jh->nama_jenis); ?></label>
            <div class="col-lg-8 col-md-8">
              <?php if($permohonan->status_hasil=='Diterima Admin' || $permohonan->status_hasil=='Publish'): ?>
              <?php else: ?>
                <input type="file" id="file_<?php echo e($jh->id_jenis_hasil); ?>" name="file_<?php echo e($jh->id_jenis_hasil); ?>" class="form-control" accept=".pdf"></br>
              <?php endif; ?>
              <?php
              $doc = App\DocHasil::where('permohonan_id',$permohonan->id_permohonan)->where('jenis_hasil_id',$jh->id_jenis_hasil)->first();
              if(!empty($doc)){
                if($doc->nama_file!=''){
                  if(file_exists('uploads/hasil_penelitian/'.$doc->nama_file)){
                    ?>
                    <a href="javascript:void(0)" class="btn btn-success" onclick="modal_view('<?php echo e($doc->nama_file); ?>')" data-toggle="modal" data-target="#myModal">File terlampir</a>
                    <?php
                    array_push($berkas_required,'file_'.$jh->id_jenis_hasil);
                  }
                }
              }
              ?>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($hasil)): ?>
          <h3>Catatan</h3>
          <p><?php echo e($hasil->catatan); ?></p>
        <?php endif; ?>
      </div>
          <label><input type="checkbox" name="kirim" onchange="required_file()" required> Jika anda yakin centang untuk di koreksi Admin</label><br>
          <input type="submit" name="" value="Upload" class="btn btn-primary">        
    </form>

    <!-- <a href="https://smallseotools.com/plagiarism-checker/" style="color: red;text-decoration: underline;">click here.</a></p> -->
    <hr style="  border: 1px solid DimGray;">
    <h3 style="font-weight: bold;">My Account</h3>
    <li><a href="<?php echo e(route('edit_profil')); ?>">Edit My Profile</a></li>
    <li><a href="<?php echo e(route('update_password')); ?>">Change My Password</a></li>
    <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
    <hr style="  border: 1px solid DimGray;">

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Modal View</h4>
          </div>
          <div class="modal-body">

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>
  </div>

  <script type="text/javascript">
    function modal_view(file){
      var ext = file.split('.');
      var html = '';
      if(ext[1]=='pdf' || ext[1]=='PDF'){
        html = '<iframe src="<?php echo e(url('/')); ?>/uploads/hasil_penelitian/'+file+'" style="height: 70vh;width: 100%"></iframe>';
      }else{
        html = '<img src="<?php echo e(url('/')); ?>/uploads/hasil_penelitian/'+file+'" style="width: 100%">';
      }

      $('.modal-body').html(html);
    }

    $( document ).ready(function() {
      required_file();
    });

    function required_file(){
      var cek = $('input[name=kirim]').is(':checked');
      if(cek==true){
        $('#summary-ckeditor').attr('required','required');
        <?php $__currentLoopData = $jenis_hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(in_array('file_'.$jh->id_jenis_hasil,$berkas_required)): ?>
        <?php else: ?>
        $('#file_<?php echo e($jh->id_jenis_hasil); ?>').attr('required','required');
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      }else{
        $('#summary-ckeditor').removeAttr('required');
        <?php $__currentLoopData = $jenis_hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        $('#file_<?php echo e($jh->id_jenis_hasil); ?>').removeAttr('required');
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      }
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>