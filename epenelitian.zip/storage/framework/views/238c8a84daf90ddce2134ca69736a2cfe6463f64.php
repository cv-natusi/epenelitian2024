<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12">
    <h1>
    <?php if(Session::get('bahasa') == 'indonesia'): ?>
        <?php echo $bahasa['bahasa2']->indonesia; ?>

      <?php else: ?>
        <?php echo $bahasa['bahasa2']->inggris; ?>

      <?php endif; ?>
  	</h1>
    <div class="list-group">
        <div class="col-lg-12 col-md-12">
            
        </div>
    </div>
    <hr style="  border: 1px solid DimGray;">
    <p style="font-weight: bold;">
    	<?php if(Session::get('bahasa') == 'indonesia'): ?>
        <?php echo $bahasa['bahasa4']->indonesia; ?>

      <?php else: ?>
        <?php echo $bahasa['bahasa4']->inggris; ?>

      <?php endif; ?>
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>