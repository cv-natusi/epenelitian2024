<div class="modal fade" id="detail-dialog" tabindex="-1" role="dialog" aria-labelledby="product-detail-dialog">
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">
      <div class="modal-header" style="width: 100%">
          Perihal Surat yang akan dicetak
        <span style="float:right"><a data-dismiss="modal">Close</a></span>
      </div>
      <div class="modal-body">
        <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
          <h4 style="font-weight: bold; color: #4682B4;">Surat Ijin</h4>
          <hr style="  border: 1px solid DimGray;">
          <div class="form-group">
            <label class="col-lg-4 col-md-4">Perihal</label>
            <div class="col-lg-8 col-md-8">
              <select class="form-control" name="jenis" onchange="view_surat(this)">
                <option value="">.:: Perihal Surat ::.</option>
                <?php if(!empty($lmb)): ?>
                  <?php $__currentLoopData = $lmb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($l->id_lembar!=1): ?>
                      <option value="<?php echo e($l->id_lembar); ?>"><?php echo e($l->keterangan); ?></option>
                    <?php else: ?>
                    <!-- UNTUK NOTA DINAS  -->
                      <!-- @ if(strpos($permohonan->tempat_penelitian, $permohonan->unit_kerja) !== false){ -->
                        <!-- <option value="<?php echo e($l->id_lembar); ?>"><?php echo e($l->keterangan); ?></option> -->
                      <!-- @ endif -->
                      <?php $__currentLoopData = $tmpt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(strpos($permohonan->unit_kerja, $t->nama_tempat) !== false): ?>{
                          <?php if($t->kategori == "Internal"): ?>{
                            <option value="<?php echo e($l->id_lembar); ?>"><?php echo e($l->keterangan); ?></option>
                          <?php endif; ?>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </select>
            </div>
          </div>
          <div class="col-lg-12 col-md-12">
            <a href="javascript:void(0)" class="btn btn-success" onclick="cetak_surat()"><i class="fa fa-print"></i>Cetak</a>
          </div>
          <div class="col-lg-12 col-md-12">
            <div id="view-surat">

            </div>
          </div>
        </div>
      </div>
      <div class="clearfix" style='padding-bottom:20px'></div>
    </div>
  </div>
</div>
<script type="text/javascript">
  $().ready(function() {
    // validate the comment form when it is submitted
    $("#commentForm").validate();
  });

    var onLoad = (function() {
        $('#detail-dialog').find('.modal-dialog').css({
            'width'     : '60%'
        });
        $('#detail-dialog').modal('show');
    })();

    $('#detail-dialog').on('hidden.bs.modal', function () {
        $('.modal-dialog').html('');
    });

    function view_surat(ini){
      if(ini.value==''){
        $('#view-surat').html('');
      }else{
        $.post("<?php echo e(route('view-surat-ijin')); ?>",{kategori:ini.value,permohonan:'<?php echo e($permohonan->id_permohonan); ?>'},function(data){
          if(data.status=='success'){
            $('#view-surat').html(data.content);
          }else{
            $('#view-surat').html('');
          }
        });
      }
    }

    function cetak_surat(){
      var jenis = $('select[name=jenis]').val();
      if(jenis==''){

      }else{
        window.open("<?php echo e(url('/')); ?>/api/cetak_surat_ijin-<?php echo e($permohonan->id_permohonan); ?>-"+jenis);
      }
    }
</script>
