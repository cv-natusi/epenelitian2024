<?php $__env->startSection('content'); ?>
  <div class="col-lg-12 col-md-12" style="background-color: #f7f7f7">
    <h1> 
      <?php if(Session::get('bahasa') == 'indonesia'): ?>
        <?php echo $bahasa['bahasa6']->indonesia; ?>

      <?php else: ?>
        <?php echo $bahasa['bahasa6']->inggris; ?>

      <?php endif; ?>
    </h1>
    <div class="col-lg-12 col-md-12">
      <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($thn->tahun); ?></h3>
        <ul>
          <li><a href="<?php echo e(url('/archive/viewArchive', [$thn->tahun, 1])); ?>">
            <?php if(Session::get('bahasa') == 'indonesia'): ?>
              <?php echo $bahasa['bahasa7']->indonesia; ?>

            <?php else: ?>
              <?php echo $bahasa['bahasa7']->inggris; ?>

            <?php endif; ?> <?php echo e($thn->tahun); ?>)</a>
          </li>
          <li><a href="<?php echo e(url('/archive/viewArchive', [$thn->tahun, 2])); ?>">
            <?php if(Session::get('bahasa') == 'indonesia'): ?>
              <?php echo $bahasa['bahasa8']->indonesia; ?>

            <?php else: ?>
              <?php echo $bahasa['bahasa8']->inggris; ?>

            <?php endif; ?> <?php echo e($thn->tahun); ?>)</a>
          </li>
        </ul>
        <hr style="border-top: 2px dotted;">
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>