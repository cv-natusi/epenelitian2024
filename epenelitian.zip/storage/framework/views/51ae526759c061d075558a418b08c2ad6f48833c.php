<?php $__env->startSection('content'); ?>
  <div class="col-lg-12 col-md-12">
    <a href="<?php echo e(url('userhome')); ?>" class="btn btn-info" style="float: right;"><i class="fa fa-backward">  Back</i></a>
  	<h3>Detail data Pengajuan</h3>
  	<hr style="  border: 1px solid DimGray;">

    <div class="tbRes">
      <table class="table table-striped">
        <thead>
          <tr class="info">
            <th>ID</th>
            <th>Judul Penelitian</th>
            <th>Jenis Penelitian</th>
            <th>Status Permohonan</th>
            <th>View</th>
          </tr>
        </thead>
        <tbody>

      

        <?php $__currentLoopData = $permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
              $terima = DB::table('doc_pendukung')->where('permohonan_id', $key->id_permohonan)
                                      ->where('doc_status','terima')->get();

              $tolak = DB::table('doc_pendukung')->where('permohonan_id', $key->id_permohonan)
                                      ->where('doc_status','tolak')->get();

              $status_doc = DB::table('doc_pendukung')->where('permohonan_id', $key->id_permohonan)
                      ->where('doc_status','pending')->get(); 
          ?>

        <tr>
            <td><?php echo e($key->id_permohonan); ?></td>
            <td><?php echo e($key->judul_penelitian); ?></td>
            <td><?php echo e($key->jenis_penelitian->nama_jenis); ?></td>
            <td>
              <!-- permohonan diterima, doc. diterima, surat belum -->
              <?php if(count($terima)>=2 && $key->surat_ijin == "" OR $key->surat_ijin == "belum"): ?>
                <span>menunggu surat ijin diterbitkan</span>

              <!-- permohonan diterima, doc.di proses -->
              <?php elseif(count($status_doc)!=0): ?>
                <span>dokumen pendukung sedang di review <i class="fa fa-refresh"></i></span>

              <!-- permohonan diterima, doc.di tolak -->
              <?php elseif(count($tolak)!=0): ?>
                <span>doc. pendukung di tolak </span> <a href="<?php echo e(url('userhome/up_doc/'.$key->id_permohonan)); ?>" style="text-decoration: underline; color: red;"><b>upload ulang</b></a> 

              <!-- permohonan status menunggu -->
              <?php elseif($key->status == 'menunggu'): ?>        
                <span>sedang di proses <i class="fa fa-refresh"></i></span>  

              <!-- permohonan ditolak -->
              <?php elseif($key->status == 'tolak'): ?>        
                <span>Judul Ditolak</span> <a href="<?php echo e(url('userhome/create')); ?>" style="text-decoration: underline; color: red;"> <b>ajukan judul yang lain</b></a>   

              <!-- permohonan diterima, doc. diterima, surat sudah diterima & konfirmasi -->
              <?php elseif($key->surat_ijin == 'sudah' && $key->status == 'terima'): ?>
                <span>surat ijin sudah diterima</span>

              <!-- permohonan diterima, doc. diterima, surat sudah diterima & belum konfirmasi -->
              <?php elseif($key->surat_ijin == 'belum di ambil' && $key->status == 'terima'): ?>
                <span>surat ijin sudah diterbitkan</span> <a href="<?php echo e(url('userhome/pernyataan/'.$key->id_permohonan)); ?>" style="text-decoration: underline; color: red;"><b>konfirmasi</b></a>

              <?php else: ?>
                  <span>permohonan diterima </span> <a href="<?php echo e(url('userhome/up_doc/'.$key->id_permohonan)); ?>" style="text-decoration: underline; color: red;"><b>upload doc. pendukung</b></a> 
              <?php endif; ?>

            </td>
            <td>
              <a href="<?php echo e(url('userhome/view/details/'.$key->id_permohonan)); ?>" style="text-decoration: underline;">Details Dokumen</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
        </tbody>
      </table>
    </div>

    <hr style="  border: 1px solid DimGray;">  
  </div>
   <script type="text/javascript">
    var lbrRes = $('.tbRes').width();
    $('.tblRes').attr('style','max-width:'+lbrRes+'px;overflow-x:scroll;')
    console.log(lbrRes);
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>