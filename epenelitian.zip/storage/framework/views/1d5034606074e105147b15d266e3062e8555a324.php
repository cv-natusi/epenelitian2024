 <div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="panel panel-primary">
      <div class="panel-heading">Tambahkan Jenis File Pendukung</div>
      <div class="panel-body">
        <form class="panel-form" method="POST" enctype="multipart/form-data" action="<?php echo e(route('docreatejenisfilependukung')); ?>"
            style="margin-top: 20px;">
            <?php echo e(csrf_field()); ?>          
          <div class="form-group">
            <label>Nama Jenis* contoh: form_penelitian </label>
            <input type="text" name="nama_jenis" class="form-control" placeholder="masukkan nama jenis file pendukung (gunakan _ untuk 2 kata atau lebih)"  class="form-control" />
          </div>        
          <div class="form-group">
            <label>Nama Form*</label>
            <input type="text" name="nama_form" class="form-control" placeholder="nama yang akan di tampilakn pada form isian"  class="form-control" />
          </div>
          <hr style="border: 1px solid DimGray;"></hr>
          <button class="btn btn-success btn-submit" type="submit">Save</button>
          <a href="<?php echo e(route('jenis_file_pendukung')); ?>" class="btn btn-danger">Kembali</a>
        </form>
      </div>
    </div>
  </div>
</div>
  <div class="other-page">
  </div>
  <div class="modal-dialog">
  </div>

