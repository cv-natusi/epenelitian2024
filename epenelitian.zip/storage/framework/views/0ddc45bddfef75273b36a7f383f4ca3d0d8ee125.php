
<!DOCTYPE html>
<html>
<head>
<title>Login Admin</title>
<!-- For-Mobile-Apps -->
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //For-Mobile-Apps -->
<!-- Style --> 
	<link rel="stylesheet" href="<?php echo e(asset('logintemp/css/style.css')); ?>" type="text/css" media="all" />
	<link rel="stylesheet" href="<?php echo e(url('css/sweetalert.css')); ?>">
	<script src="<?php echo e(url('js/sweetalert.min.js')); ?>"></script>
</head>
<body>
	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
	<div class="footer">
	     <p>Copyright &copy; 2019 DInas Kesehatan Kabupaten SIdoarjo. Jl. Mayjend Sungkono 46 Sidoarjo.</p>
	</div>
</body>
<script>
  <?php if(Session::has('message')): ?>
  	swal('<?php echo e(Session::get('title')); ?>','<?php echo e(Session::get('message')); ?>','<?php echo e(Session::get('type')); ?>');
  <?php endif; ?>
</script>
</html>