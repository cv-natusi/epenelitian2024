<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <style>
    *{
      font-family: arial;
    }
  </style>
  <body>
    <?php echo $data; ?>

  </body>
  <script type="text/javascript">
  window.focus();
  window.print();
  setTimeout(function () { window.close(); }, 100);
  </script>
</html>
