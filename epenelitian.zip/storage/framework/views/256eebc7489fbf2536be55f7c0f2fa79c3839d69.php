<?php $__env->startSection('content'); ?>
<form class="form-horizontal" method="post" action="<?php echo e(route('store_permohonan')); ?>" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <input type="hidden" name="id_permohonan" value="<?php echo e($permohonan->id_permohonan); ?>"/>
  <div class="alert alert-danger" role="alert">
    <?php echo e($permohonan->judul_penelitian); ?> Ditolak<br> 
    Catatan : <?php echo e($permohonan->catatan); ?>

  </div>
  
  <div class="col-lg-12 col-md-12">
    <div class="section-header">
        <h4 style="font-weight: bold;">File Persyaratan Lama</h4>
        <p>File Persyaratan Lama Sebelum Revisi.</p>
        <hr style="  border: 1px solid DimGray;">
    </div>
  </div>
  <div class="col-lg-12 col-md-12 col-sm-12" style="margin-bottom: 30px">
    <div class="form-group row">
        <label class="col-sm-4 col-form-label"> Proposal Penelitian Lama:</label>
        <div class="col-sm-8">
          <a class="btn btn-warning col-sm-12" href="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($permohonan->upload_proposal_penelitian); ?>" download="LAMPIRAN_02_SURAT_PERNYATAAN_PEMOHON">Download File Lama</a>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-4 col-form-label"> Surat Pengantar dari Universitas/Instansi Lain Lama:</label>
        <div class="col-sm-8">
          <a class="btn btn-warning col-sm-12" href="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($permohonan->upload_surat_pengantar); ?>" download="LAMPIRAN_02_SURAT_PERNYATAAN_PEMOHON">Download File Lama</a>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-4 col-form-label"> Surat Rekomendasi Bakesbangpol Kabupaten Sidoarjo Lama:</label>
        <div class="col-sm-8">
          <a class="btn btn-warning col-sm-12" href="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($permohonan->upload_surat_rekomendasi); ?>" download="LAMPIRAN_02_SURAT_PERNYATAAN_PEMOHON">Download File Lama</a>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-4 col-form-label"> Surat Pernyataan Peneliti Lama:</label>
        
        <div class="col-sm-8">
          <a class="btn btn-warning col-sm-12" href="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($permohonan->upload_surat_pernyataan); ?>" download="LAMPIRAN_01_LEMBAR_PERSETUJUAN_PEMEGANG_PROGRAM_YG_AKAN_DITELITI">Download File Lama</a>
        </div>
    </div>

    <div class="form-group row">
        <label class="col-sm-4 col-form-label"> Surat Kesediaan Pemegang Program Instansi yang akan diteliti Lama:</label>
        
        <div class="col-sm-8">
          <a class="btn btn-warning col-sm-12" href="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($permohonan->upload_surat_kesediaan); ?>" download="LAMPIRAN_02_SURAT_PERNYATAAN_PEMOHON">Download File Lama</a>
        </div>
    </div>
  </div>
  
  <div class="col-lg-12 col-md-12">
    <div class="section-header">
        <h4 style="font-weight: bold;">Form Upload Persyaratan</h4>
        <p>Revisi Formulir Permohonan Persyaratan.</p>
        <hr style="  border: 1px solid DimGray;">
    </div>
  </div>
  <div class="col-lg-12 col-md-12">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="form-group row">
            <label class="col-sm-4 col-form-label"> Proposal Penelitian:</label>
            <div class="col-sm-8">
                <input type="file" class="form-control disablecopypaste" name="upload_proposal_penelitian" placeholder="Upload Proposal Penelitian">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-4 col-form-label"> Surat Pengantar dari Universitas/Instansi Lain:</label>
            <div class="col-sm-8">
                <input type="file" class="form-control disablecopypaste" name="upload_surat_pengantar" placeholder="Upload Surat Pengantar">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-4 col-form-label"> Surat Rekomendasi Bakesbangpol Kabupaten Sidoarjo:</label>
            <div class="col-sm-8">
                <input type="file" class="form-control disablecopypaste" name="upload_surat_rekomendasi" placeholder="Upload Surat rekomendasi">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-4 col-form-label"> Surat Pernyataan Peneliti:</label>
            
            <div class="col-sm-2">
              <a class="btn btn-primary col-sm-12" href="<?php echo e(asset('lampiran/LAMPIRAN_01_LEMBAR_PERSETUJUAN_PEMEGANG_PROGRAM_YG_AKAN_DITELITI.docx')); ?>" download="LAMPIRAN_01_LEMBAR_PERSETUJUAN_PEMEGANG_PROGRAM_YG_AKAN_DITELITI">Download</a>
            </div>
            <div class="col-sm-6">
              <input type="file" class="form-control disablecopypaste" name="upload_surat_pernyataan" placeholder="Upload Surat Pernyataan" required>
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-4 col-form-label"> Surat Kesediaan Pemegang Program Instansi yang akan diteliti:</label>
            
            <div class="col-sm-2">
              <a class="btn btn-primary col-sm-12" href="<?php echo e(asset('lampiran/LAMPIRAN_02_SURAT_PERNYATAAN_PEMOHON.docx')); ?>" download="LAMPIRAN_02_SURAT_PERNYATAAN_PEMOHON">Download</a>
            </div>
            <div class="col-sm-6">
                <input type="file" class="form-control disablecopypaste" name="upload_surat_kesediaan" placeholder="Upload Surat Kesediaan" required>
                <label class="custom-control-label" style="color: red;">*download dulu file aslinya.</label>
            </div>
        </div>
        
        <div class="form-group" style="float: right;">
            <button type="submit" class="btn btn-success">SIMPAN</button>
            <a href="<?php echo e(route('userhome')); ?>" class="btn btn-danger">BATAL</a>
        </div>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">

   $(document).ready(function () {
      $('input.disablecopypaste').bind('copy paste', function (e) {
         e.preventDefault();
      });
      $('textarea.disablecopypaste').bind('copy paste', function (e) {
         e.preventDefault();
      });
    });

   function cekAngka(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
      if (charCode > 31 && (charCode < 48 || charCode > 57) || charCode == 32 || charCode == 46 || charCode == 64)
        return false;
      return true;
    }
 
    function cekAngkaHuruf(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
      if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (charCode >= 48 && charCode <= 57) || (charCode == 44 || charCode == 46)  || charCode == 32 || charCode == 45 || charCode == 47 || charCode == 64){
        return true;
      }else{
        return false;
      }
    }

  var dataUnitKerja = new Array();
  $('#unit_kerja').keyup(function(){
    var value = $('#unit_kerja').val();
    //silfi
    var value_tempat = $('select[name=jenis_penelitian_id').val();
    //
    if (value) {
      $.post("<?php echo e(url('api/get_tempat')); ?>",{value:value,value_tempat:value_tempat},function(data){
        //
        var html = '';
        if(data.status=='success'){
          for (var i = 0; i < data.tempat_penelitian.length; i++) {
            html+='<a href="javascript:void(0)" onclick="set_unit(\''+data.tempat_penelitian[i]+'\')">'+data.tempat_penelitian[i].substring(data.tempat_penelitian[i].indexOf("_")+2, data.tempat_penelitian[i].length)+'</a><br>';
            dataUnitKerja = data.tempat_penelitian;
          }
        }
        $('#tempat-unit').html(html);
      });
    } else {
        $('#tempat-unit').html('');
    }
  });


function set_unit(unit){
  $('#unit_kerja').val(unit.substring(unit.indexOf("_")+2, unit.length));
  $('#unit_kerja_hidden').val(unit);
  $('#tempat-unit').html('');
}

$('input[name=tgl_awal]').datetimepicker({
  weekStart: 1,
  todayBtn:  1,
  autoclose: 1,
  todayHighlight: 1,
  startView: 2,
  format: 'yyyy-mm-dd',
  minView: 2,
  forceParse: 0,
});
$('input[name=tgl_akhir]').datetimepicker({
  weekStart: 1,
  todayBtn:  1,
  autoclose: 1,
  todayHighlight: 1,
  startView: 2,
  format: 'yyyy-mm-dd',
  minView: 2,
  forceParse: 0,
});

function tambah_tempat(){
  var tempat = $('#unit_kerja').val();
  var tempatHidden = $('#unit_kerja_hidden').val();
  var wadah = $('textarea[name=unit_kerja]').val();

  if(dataUnitKerja.indexOf(tempatHidden) !== -1){
    if(wadah!=''){
      if(wadah.indexOf(tempatHidden)<0){
        wadah += '|'+tempatHidden;
      }else{
        wadah = wadah;
      }
    }else{
      wadah += tempatHidden;
    }

    $('#unit_kerja').val('');
    $('#unit_kerja_hidden').val('');
    var kata = wadah.split("|");
    susun(kata);
  } else{
    $('#unit_kerja').val('');
    $('#unit_kerja_hidden').val('');
    $('#tempat-unit').html('');
    swal("Data yang Anda Pilih Kosong / Tidak ditemukan");
  }
}

function hapus(id){
  var wadah = $('textarea[name=unit_kerja]').val();
  var kata = wadah.split("|");

  var pakai = [];
  var j = 0;
  if(kata.length!=0){
    for (var i = 0; i < kata.length; i++) {
      if(i==id){

      }else{
        pakai[j] = kata[i];
        j++;
      }
    }
  }

  susun(pakai);
}

function susun(kata){
  var html = '';
  if(kata.length!=0){
    for (var i = 0; i < kata.length; i++) {
      html+='<a href="javascript:void(0)" class="btn btn-success" style="margin-right: 10px" onclick="hapus(\''+i+'\')">'+kata[i].substring(kata[i].indexOf("_")+2, kata[i].length)+'</a>';
    }
  }

  var wadah = kata.join("|");

  $('textarea[name=unit_kerja]').html(wadah);
  $('#hasil-unit').html(html);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>