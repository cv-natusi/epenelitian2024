<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12">
    <h1>Sitemap</h1>
    <div class="col-lg-12 col-md-12">
	    <div class="panel panel-primary">
	      <div class="panel-heading">
	      	<h4>Details Journal</h4>
	      </div>
	      <div class="panel-body">
	      	<iframe src="<?php echo e(url('/')); ?>/uploads/hasil_penelitian/<?php echo e($submission->nama_file); ?>" type="application/pdf" width="100%" height="680px">This browser does not support PDFs. Please download the PDF to view it: Download PDF</iframe>
	      </div>
	    </div>
  	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>