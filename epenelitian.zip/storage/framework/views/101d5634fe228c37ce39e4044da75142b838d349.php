  <div class="row">
    <div class="col-lg-12 col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <?php echo e($title); ?>

        </div>
      </div>
    </div>
  </div>
      <a href="" class="btn btn-primary">Back</a>
  <div class="row">
    <div class='col-lg-6 col-md-6 col-sm-6 col-xs-6'>
      <!-- <img src="<?php echo e(url('/')); ?>/uploads/images/<?php echo e($users_id->image); ?>" align="center"alt="" height="150px" width="auto"> -->
      <h4 style="font-weight: bold; color: #4682B4;">Keterangan Datadiri</h4>
      <hr style="  border: 1px solid DimGray;">
        <div class="form-group">
          <table class="table">
            <tbody>
                <tr>
                  <th>Nama Lengkap</th>
                    <td>: <?php echo e($users_id->first_name); ?> <?php echo e($users_id->middle_name); ?> <?php echo e($users_id->last_name); ?></td>
                </tr>
                <tr>
                  <th>Nomor Telepon</th>
                    <td>: <?php echo e($users_id->phone); ?></td>
                </tr>
                <!-- <tr>
                  <th>Initials</th>
                    <td>: <?php echo e($users_id->initials); ?></td>
                </tr> -->
                <tr>
                  <th>Jenis Kelamin</th>
                    <td>: <?php echo e($users_id->gender); ?></td>
                </tr>
                <!-- <tr>
                  <th>Orcid ID</th>
                    <td>: <?php echo e($users_id->id_orcid); ?></td>
                </tr> -->
                <!-- <tr>
                  <th>Interest</th>
                    <td>: <?php echo e($users_id->identify); ?></td>
                </tr>
                <tr>
                  <th>Bio</th>
                    <td>: <?php echo e($users_id->bio); ?></td>
                </tr> -->
            </tbody>
          </table>
        </div>
    </div>

    <div class='col-lg-6 col-md-6 col-sm-6 col-xs-6'>
      <h4 style="font-weight: bold; color: #4682B4;">Keterangan Alamat</h4>
      <hr style="  border: 1px solid DimGray;">
        <div class="form-group m-t-0 m-b-25">
          <table class="table">
            <tbody>
                <!-- <tr>
                  <th>No Fax</th>
                    <td>: <?php echo e($users_id->fax); ?></td>
                </tr> -->
                <tr>
                  <th>Asal Negara</th>
                    <td>: <?php echo e($users_id->country); ?></td>
                </tr>
                <!-- <tr>
                  <th>Affiliation</th>
                    <td>: <?php echo e($users_id->affiliation); ?></td>
                </tr> -->
                <!-- <tr>
                  <th>Signature</th>
                    <td>: <?php echo e($users_id->signature); ?></td>
                </tr> -->
                <tr>
                  <th>Email</th>
                    <td>: <?php echo e($users_id->email); ?></td>
                </tr>
                <tr>
                  <th>Alamat</th>
                    <td>: <?php echo $users_id->mailing_ads; ?></td>
                </tr>
            </tbody>
          </table>
        </div>
    </div>

  </div>
