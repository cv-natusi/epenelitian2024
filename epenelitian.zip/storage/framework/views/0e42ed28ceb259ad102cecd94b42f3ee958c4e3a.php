<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12">
    <a href="<?php echo e(url('userhome/')); ?>" class="btn btn-info" style="float: right;"><i class="fa fa-backward">  Back</i></a>
	  <div class="section-header">
        <h4 style="font-weight: bold;">Form Permohonan</h4>
        <p>Buat Permohonan Pengajuan Penelitian.</p>
        <hr style="  border: 1px solid DimGray;">
    </div>
</div>
  <div class="col-lg-12 col-md-12">
    <form class="form-horizontal" method="post" action="<?php echo e(route('store_permohonan')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

      <div class="col-lg-12 col-md-12 col-sm-12">
         <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Pilih Jenis Penelitian:</label>
          <div class="col-sm-8">
            <select class="form-control" name="jenis_penelitian_id" required>
              <option value="" selected style="font-weight: bold;"> .:: Pilih Jenis Penelitian ::. </option>
              <?php $__currentLoopData = $jenis_penelitian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($jp->id_jenis_penelitian); ?>"><?php echo e($jp->nama_jenis); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Judul Penelitian:</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" name="judul_penelitian" placeholder="Masukkan Judul Penelitian yang akan anda buat" required>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Tempat Penelitian:</label>
          <div class="col-lg-6 col-md-6 col-sm-6">
            <textarea name="unit_kerja" style="opacity: 0;position: absolute;z-index:-99" required></textarea>
            <input type="text" id="unit_kerja" value="" placeholder="Silahkan Ketikkan Kata Kunci..." class="form-control" autocomplete="off">
            <div id="tempat-unit">

            </div>
            <div id="hasil-unit">

            </div>
          </div>
          <div class="col-lg-1 col-md-1">
            <a href="javascript:void(0)" class="btn btn-success" onclick="tambah_tempat()"><i class="fa fa-plus"></i></a>
          </div>
        </div>

         <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Tanggal Awal:</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" name="tgl_awal" autocomplete="off" placeholder="Tanggal Mulai Penelitian" required>
          </div>
        </div>

         <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Tanggal Akhir:</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" name="tgl_akhir" autocomplete="off" placeholder="Tanggal Selesai Penelitian" required>
            <label class="custom-control-label" style="color: red;">*sesuai dengan surat rekomendasi dari Bakesbanpol.</label>
          </div>
        </div>

        <div class="form-group" style="float: right;">
          <button type="submit" class="btn btn-success">SIMPAN</button>
          <a href="<?php echo e(route('userhome')); ?>" class="btn btn-danger">BATAL</a>
        </div>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  var dataUnitKerja = new Array();
  $('#unit_kerja').keyup(function(){
    var value = $('#unit_kerja').val();
    if (value) {
      $.post("<?php echo e(url('api/get_tempat')); ?>",{value:value},function(data){
        var html = '';
        if(data.status=='success'){
          for (var i = 0; i < data.tempat_penelitian.length; i++) {
            html+='<a href="javascript:void(0)" onclick="set_unit(\''+data.tempat_penelitian[i]+'\')">'+data.tempat_penelitian[i]+'</a><br>';
            dataUnitKerja = data.tempat_penelitian;
          }
        }
        $('#tempat-unit').html(html);
      });
    } else {
        $('#tempat-unit').html('');
    }
  });

function set_unit(unit){
  $('#unit_kerja').val(unit);
  $('#tempat-unit').html('');
}

$('input[name=tgl_awal]').datetimepicker({
  weekStart: 1,
  todayBtn:  1,
  autoclose: 1,
  todayHighlight: 1,
  startView: 2,
  format: 'yyyy-mm-dd',
  minView: 2,
  forceParse: 0,
});
$('input[name=tgl_akhir]').datetimepicker({
  weekStart: 1,
  todayBtn:  1,
  autoclose: 1,
  todayHighlight: 1,
  startView: 2,
  format: 'yyyy-mm-dd',
  minView: 2,
  forceParse: 0,
});

function tambah_tempat(){
  var tempat = $('#unit_kerja').val();
  var wadah = $('textarea[name=unit_kerja]').val();

  if(dataUnitKerja.indexOf(tempat) !== -1){
    if(wadah!=''){
      if(wadah.indexOf(tempat)<0){
        wadah += '|'+tempat;
      }else{
        wadah = wadah;
      }
    }else{
      wadah += tempat;
    }

    $('#unit_kerja').val('');
    var kata = wadah.split("|");
    susun(kata);
  } else{
    $('#unit_kerja').val('');
    $('#tempat-unit').html('');
    swal("Data yang Anda Pilih Kosong / Tidak ditemukan");
  }
}

function hapus(id){
  var wadah = $('textarea[name=unit_kerja]').val();
  var kata = wadah.split("|");

  var pakai = [];
  var j = 0;
  if(kata.length!=0){
    for (var i = 0; i < kata.length; i++) {
      if(i==id){

      }else{
        pakai[j] = kata[i];
        j++;
      }
    }
  }

  susun(pakai);
}

function susun(kata){
  var html = '';
  if(kata.length!=0){
    for (var i = 0; i < kata.length; i++) {
      html+='<a href="javascript:void(0)" class="btn btn-success" style="margin-right: 10px" onclick="hapus(\''+i+'\')">'+kata[i]+'</a>';
    }
  }

  var wadah = kata.join("|");

  $('textarea[name=unit_kerja]').html(wadah);
  $('#hasil-unit').html(html);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>