<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <style>
    *{
      font-family: arial;
    }
  </style>
  <body>
    <div style="width: 21cm;">
      <?php echo $data; ?>

    </div>
  </body>
  <script type="text/javascript">
  // window.focus();
  // window.print();
  function tutup(){
    // setTimeout(function () { window.close(); }, 100);
    window.close();
  }
  </script>
</html>
