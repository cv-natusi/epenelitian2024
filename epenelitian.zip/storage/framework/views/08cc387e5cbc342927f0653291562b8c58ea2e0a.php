<?php $__env->startSection('content'); ?>
<h1>login admin</h1>
<div class="contact-form">
  <div class="signin">
    <form method="post" action="<?php echo e(route('dolog_admin')); ?>" class="form-login">
          <?php echo e(csrf_field()); ?>

	      <input type="text" class="user" name="username" value="Enter Username" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Username';}" />
	      <input type="password" class="pass" name="password" value="Your Password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Your Password';}" />
          <input type="submit" value="LOGIN" />
          <p>Not a member? <a href="<?php echo e(url('/registrasi')); ?>">Signup now >></a> </p>
	</form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>