<?php $__env->startSection('content'); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<div class="row">
	<div class="col-lg-8 col-md-6 col-sm-6 col-lg-offset-2" style="border: 5px solid #f1f1f1;background-color: #EFEFEF;">

		<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>

		<form method="POST" id="formReg" enctype="multipart/form-data" action="<?php echo e(route('regis_store')); ?>" style="margin-top: 20px;">
			<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<label>Nama Pengguna</label>
				<input type="text" name="username" placeholder="Enter Username" required="" value="<?php echo e(old('username')); ?>" class="form-control" >
				<small class="form-text text-muted" style="color: red;">Nama Pengguna ini digunakan untuk Login akun anda.</small>
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="password" min="6" required="" placeholder="enter password" class="form-control password" >
				<div id="pass">
					<small class="form-text text-muted" style="color: red;">Password harus lebih dari 6 karakter.</small>
				</div>
			</div>
			<div class="form-group">
				<label>Konfirmasi Password</label>
				<input type="password" name="confirm_password" onkeyup="samePass()" required="" placeholder="konfirmasi password" class="form-control confirm_password">
				<small class="form-text text-muted statusPass" style="color: red; font-weight: 900px;">Masukkan kembali password yang sama.</small>
			</div>
			<!-- <div class="g-recaptcha" data-sitekey="6LfNGrUUAAAAADA-Ll4gX8hnHZo1VNfHp9znb5fL"></div> -->
			
			<div class="form-group">
				<label>Nama Depan</label>
				<input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" required="" placeholder="First Name" class="form-control">
			</div>
			<div class="form-group">
				<label>Nama Tangah</label>
				<input type="text" name="middle_name" value="<?php echo e(old('middle_name')); ?>" placeholder="Middle Name" class="form-control">
			</div>
			<div class="form-group">
				<label>Nama Belakang</label>
				<input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" required="" placeholder="Last Name" class="form-control">
			</div>
			<div class="form-group">
				<label>Status Pekerjaan : </label>
				<label class="radio-inline">
					<input type="radio" name="category" value="pns" <?php echo e((old("category")=="pns")? "checked" : ""); ?> required onclick="show_form()"><b>ASN</b>
				</label>
				<!-- <label class="radio-inline">
					<input type="radio" name="category" value="dosen" <?php echo e((old("category")=="dosen")? "checked" : ""); ?> onclick="show_form()"><b>Dosen</b>
				</label> -->
				<label class="radio-inline">
					<input type="radio" name="category" value="mhs" <?php echo e((old("category")=="mhs")? "checked" : ""); ?> onclick="show_form()"><b>Mahasiswa</b>
				</label>
				<label class="radio-inline">
					<input type="radio" name="category" value="umum" <?php echo e((old("category")=="umum")? "checked" : ""); ?> onclick="show_form()"><b>Lainnya</b>
				</label>
			</div>


			<div class="form-group" id="div-instansi">
				<label id="instansi"></label>
				<input type="text" id="unit_instansi" name="unit_instansi" value="<?php echo e(old('unit_instansi')); ?>" class="form-control" required>
				<div id="tempat-instansi">

				</div>
			</div>
			<div class="form-group" id="div-kerja">
				<label id="kerja"></label>
				<input type="text" id="unit_kerja" name="unit_kerja" value="<?php echo e(old('unit_kerja')); ?>" class="form-control" required>
				<div id="tempat-kerja">

				</div>
			</div>
			<div class="form-group" id="div-no-identitas">
				<label id="no-identitas"></label>
				<input type="number" name="no_identitas" value="<?php echo e(old('no_identitas')); ?>" class="form-control" required>
			</div>

			<div class="form-group">
				<label>Jenjang</label>
				<select class="form-control" name="jenjang" id="exampleFormControlSelect1" required>
					<option value="">-- Pilih Jenjang --</option>
					<option value="D1" <?php if(old('jenjang') == "D1"): ?> <?php echo e('selected'); ?> <?php endif; ?> >D1</option>
					<option value="D2" <?php if(old('jenjang') == "D2"): ?> <?php echo e('selected'); ?> <?php endif; ?> >D2</option>
					<option value="D3" <?php if(old('jenjang') == "D3"): ?> <?php echo e('selected'); ?> <?php endif; ?> >D3</option>
					<option value="S1" <?php if(old('jenjang') == "S1"): ?> <?php echo e('selected'); ?> <?php endif; ?> >S1</option>
					<option value="S2" <?php if(old('jenjang') == "S2"): ?> <?php echo e('selected'); ?> <?php endif; ?> >S2</option>
					<option value="S3" <?php if(old('jenjang') == "S3"): ?> <?php echo e('selected'); ?> <?php endif; ?> >S3</option>
				</select>
			</div>

			<div class="form-group">
				<label>Nama Jurusan</label>
				<input type="text" name="pendidikan_terakhir" value="<?php echo e(old('pendidikan_terakhir')); ?>" placeholder="Nama Jurusan" class="form-control" required>
			</div>

			<div class="form-group">
				<label>Jenis Kelamin</label>
				<select class="form-control" name="gender" id="exampleFormControlSelect1" required>
					<option value="male" <?php if(old('gener') == "male"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Laki-laki</option>
					<option value="female" <?php if(old('gener') == "female"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Perempuan</option>
				</select>
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="text" name="email" value="<?php echo e(old('email')); ?>" required="" placeholder="Email" class="form-control">
				<small class="form-text text-muted" style="color: red;">Gunakan Email aktif.</small>
			</div>
			<div class="form-group">
				<label>Nomor Telepon</label>
				<input type="number" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Phone" class="form-control">
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<textarea class="form-control" value="" id="summary-ckeditor" name="mailing_ads" required><?php echo e(old('mailing_ads')); ?></textarea>
			</div>
			
			<div class="form-group">
				<label>Asal Negara</label>
				<select class="form-control" name="country">
					<option value="AF" <?php if(old('country') == "AF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Afghanistan</option>
					<option value="AX" <?php if(old('country') == "AX"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Åland Islands</option>
					<option value="AL" <?php if(old('country') == "AL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Albania</option>
					<option value="DZ" <?php if(old('country') == "DZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Algeria</option>
					<option value="AS" <?php if(old('country') == "AS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >American Samoa</option>
					<option value="AD" <?php if(old('country') == "AD"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Andorra</option>
					<option value="AO" <?php if(old('country') == "AO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Angola</option>
					<option value="AI" <?php if(old('country') == "AI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Anguilla</option>
					<option value="AQ" <?php if(old('country') == "AQ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Antarctica</option>
					<option value="AG" <?php if(old('country') == "AG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Antigua and Barbuda</option>
					<option value="AR" <?php if(old('country') == "AR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Argentina</option>
					<option value="AM" <?php if(old('country') == "AM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Armenia</option>
					<option value="AW" <?php if(old('country') == "AW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Aruba</option>
					<option value="AU" <?php if(old('country') == "AU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Australia</option>
					<option value="AT" <?php if(old('country') == "AT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Austria</option>
					<option value="AZ" <?php if(old('country') == "AZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Azerbaijan</option>
					<option value="BS" <?php if(old('country') == "BS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bahamas</option>
					<option value="BH" <?php if(old('country') == "BH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bahrain</option>
					<option value="BD" <?php if(old('country') == "BD"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bangladesh</option>
					<option value="BB" <?php if(old('country') == "BB"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Barbados</option>
					<option value="BY" <?php if(old('country') == "BY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Belarus</option>
					<option value="BE" <?php if(old('country') == "BE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Belgium</option>
					<option value="BZ" <?php if(old('country') == "BZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Belize</option>
					<option value="BJ" <?php if(old('country') == "BJ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Benin</option>
					<option value="BM" <?php if(old('country') == "BM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bermuda</option>
					<option value="BT" <?php if(old('country') == "BT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bhutan</option>
					<option value="BO" <?php if(old('country') == "BO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bolivia, Plurinational State of</option>
					<option value="BQ" <?php if(old('country') == "BQ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bonaire, Sint Eustatius and Saba</option>
					<option value="BA" <?php if(old('country') == "BA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bosnia and Herzegovina</option>
					<option value="BW" <?php if(old('country') == "BW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Botswana</option>
					<option value="BV" <?php if(old('country') == "BV"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bouvet Island</option>
					<option value="BR" <?php if(old('country') == "BR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Brazil</option>
					<option value="IO" <?php if(old('country') == "IO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >British Indian Ocean Territory</option>
					<option value="BN" <?php if(old('country') == "BN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Brunei Darussalam</option>
					<option value="BG" <?php if(old('country') == "BG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Bulgaria</option>
					<option value="BF" <?php if(old('country') == "BF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Burkina Faso</option>
					<option value="BI" <?php if(old('country') == "BI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Burundi</option>
					<option value="KH" <?php if(old('country') == "KH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Cambodia</option>
					<option value="CM" <?php if(old('country') == "CM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Cameroon</option>
					<option value="CA" <?php if(old('country') == "CA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Canada</option>
					<option value="CV" <?php if(old('country') == "CV"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Cape Verde</option>
					<option value="KY" <?php if(old('country') == "KY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Cayman Islands</option>
					<option value="CF" <?php if(old('country') == "CF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Central African Republic</option>
					<option value="TD" <?php if(old('country') == "TD"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Chad</option>
					<option value="CL" <?php if(old('country') == "CL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Chile</option>
					<option value="CN" <?php if(old('country') == "CN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >China</option>
					<option value="CX" <?php if(old('country') == "CX"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Christmas Island</option>
					<option value="CC" <?php if(old('country') == "CC"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Cocos (Keeling) Islands</option>
					<option value="CO" <?php if(old('country') == "CO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Colombia</option>
					<option value="KM" <?php if(old('country') == "KM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Comoros</option>
					<option value="CG" <?php if(old('country') == "CG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Congo</option>
					<option value="CD" <?php if(old('country') == "CD"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Congo, the Democratic Republic of the</option>
					<option value="CK" <?php if(old('country') == "CK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Cook Islands</option>
					<option value="CR" <?php if(old('country') == "CR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Costa Rica</option>
					<option value="CI" <?php if(old('country') == "CI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Côte d'Ivoire</option>
					<option value="HR" <?php if(old('country') == "HR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Croatia</option>
					<option value="CU" <?php if(old('country') == "CU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Cuba</option>
					<option value="CW" <?php if(old('country') == "CW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Curaçao</option>
					<option value="CY" <?php if(old('country') == "CY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Cyprus</option>
					<option value="CZ" <?php if(old('country') == "CZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Czech Republic</option>
					<option value="DK" <?php if(old('country') == "DK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Denmark</option>
					<option value="DJ" <?php if(old('country') == "DJ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Djibouti</option>
					<option value="DM" <?php if(old('country') == "DM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Dominica</option>
					<option value="DO" <?php if(old('country') == "DO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Dominican Republic</option>
					<option value="EC" <?php if(old('country') == "EC"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Ecuador</option>
					<option value="EG" <?php if(old('country') == "EG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Egypt</option>
					<option value="SV" <?php if(old('country') == "SV"): ?> <?php echo e('selected'); ?> <?php endif; ?> >El Salvador</option>
					<option value="GQ" <?php if(old('country') == "GQ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Equatorial Guinea</option>
					<option value="ER" <?php if(old('country') == "ER"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Eritrea</option>
					<option value="EE" <?php if(old('country') == "EE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Estonia</option>
					<option value="ET" <?php if(old('country') == "ET"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Ethiopia</option>
					<option value="FK" <?php if(old('country') == "FK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Falkland Islands (Malvinas)</option>
					<option value="FO" <?php if(old('country') == "FO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Faroe Islands</option>
					<option value="FJ" <?php if(old('country') == "FJ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Fiji</option>
					<option value="FI" <?php if(old('country') == "FI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Finland</option>
					<option value="FR" <?php if(old('country') == "FR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >France</option>
					<option value="GF" <?php if(old('country') == "GF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >French Guiana</option>
					<option value="PF" <?php if(old('country') == "PF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >French Polynesia</option>
					<option value="TF" <?php if(old('country') == "TF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >French Southern Territories</option>
					<option value="GA" <?php if(old('country') == "GA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Gabon</option>
					<option value="GM" <?php if(old('country') == "GM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Gambia</option>
					<option value="GE" <?php if(old('country') == "GE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Georgia</option>
					<option value="DE" <?php if(old('country') == "DE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Germany</option>
					<option value="GH" <?php if(old('country') == "GH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Ghana</option>
					<option value="GI" <?php if(old('country') == "GI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Gibraltar</option>
					<option value="GR" <?php if(old('country') == "GR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Greece</option>
					<option value="GL" <?php if(old('country') == "GL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Greenland</option>
					<option value="GD" <?php if(old('country') == "GD"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Grenada</option>
					<option value="GP" <?php if(old('country') == "GP"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Guadeloupe</option>
					<option value="GU" <?php if(old('country') == "GU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Guam</option>
					<option value="GT" <?php if(old('country') == "GT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Guatemala</option>
					<option value="GG" <?php if(old('country') == "GG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Guernsey</option>
					<option value="GN" <?php if(old('country') == "GN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Guinea</option>
					<option value="GW" <?php if(old('country') == "GW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Guinea-Bissau</option>
					<option value="GY" <?php if(old('country') == "GY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Guyana</option>
					<option value="HT" <?php if(old('country') == "HT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Haiti</option>
					<option value="HM" <?php if(old('country') == "HM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Heard Island and McDonald Islands</option>
					<option value="VA" <?php if(old('country') == "VA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Holy See (Vatican City State)</option>
					<option value="HN" <?php if(old('country') == "HN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Honduras</option>
					<option value="HK" <?php if(old('country') == "HK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Hong Kong</option>
					<option value="HU" <?php if(old('country') == "HU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Hungary</option>
					<option value="IS" <?php if(old('country') == "IS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Iceland</option>
					<option value="IN" <?php if(old('country') == "IN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >India</option>
					<option value="ID" <?php if(old('country') == "ID"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Indonesia</option>
					<option value="IR" <?php if(old('country') == "IR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Iran, Islamic Republic of</option>
					<option value="IQ" <?php if(old('country') == "IQ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Iraq</option>
					<option value="IE" <?php if(old('country') == "IE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Ireland</option>
					<option value="IM" <?php if(old('country') == "IM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Isle of Man</option>
					<option value="IL" <?php if(old('country') == "IL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Israel</option>
					<option value="IT" <?php if(old('country') == "IT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Italy</option>
					<option value="JM" <?php if(old('country') == "JM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Jamaica</option>
					<option value="JP" <?php if(old('country') == "JP"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Japan</option>
					<option value="JE" <?php if(old('country') == "JE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Jersey</option>
					<option value="JO" <?php if(old('country') == "JO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Jordan</option>
					<option value="KZ" <?php if(old('country') == "KZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Kazakhstan</option>
					<option value="KE" <?php if(old('country') == "KE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Kenya</option>
					<option value="KI" <?php if(old('country') == "KI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Kiribati</option>
					<option value="KP" <?php if(old('country') == "KP"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Korea, Democratic People's Republic of</option>
					<option value="KR" <?php if(old('country') == "KR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Korea, Republic of</option>
					<option value="KW" <?php if(old('country') == "KW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Kuwait</option>
					<option value="KG" <?php if(old('country') == "KG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Kyrgyzstan</option>
					<option value="LA" <?php if(old('country') == "LA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Lao People's Democratic Republic</option>
					<option value="LV" <?php if(old('country') == "LV"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Latvia</option>
					<option value="LB" <?php if(old('country') == "LB"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Lebanon</option>
					<option value="LS" <?php if(old('country') == "LS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Lesotho</option>
					<option value="LR" <?php if(old('country') == "LR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Liberia</option>
					<option value="LY" <?php if(old('country') == "LY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Libya</option>
					<option value="LI" <?php if(old('country') == "LI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Liechtenstein</option>
					<option value="LT" <?php if(old('country') == "LT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Lithuania</option>
					<option value="LU" <?php if(old('country') == "LU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Luxembourg</option>
					<option value="MO" <?php if(old('country') == "MO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Macao</option>
					<option value="MK" <?php if(old('country') == "MK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Macedonia, the former Yugoslav Republic of</option>
					<option value="MG" <?php if(old('country') == "MG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Madagascar</option>
					<option value="MW" <?php if(old('country') == "MW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Malawi</option>
					<option value="MY" <?php if(old('country') == "MY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Malaysia</option>
					<option value="MV" <?php if(old('country') == "MV"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Maldives</option>
					<option value="ML" <?php if(old('country') == "ML"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Mali</option>
					<option value="MT" <?php if(old('country') == "MT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Malta</option>
					<option value="MH" <?php if(old('country') == "MH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Marshall Islands</option>
					<option value="MQ" <?php if(old('country') == "MQ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Martinique</option>
					<option value="MR" <?php if(old('country') == "MR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Mauritania</option>
					<option value="MU" <?php if(old('country') == "MU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Mauritius</option>
					<option value="YT" <?php if(old('country') == "YT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Mayotte</option>
					<option value="MX" <?php if(old('country') == "MX"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Mexico</option>
					<option value="FM" <?php if(old('country') == "FM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Micronesia, Federated States of</option>
					<option value="MD" <?php if(old('country') == "MD"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Moldova, Republic of</option>
					<option value="MC" <?php if(old('country') == "MC"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Monaco</option>
					<option value="MN" <?php if(old('country') == "MN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Mongolia</option>
					<option value="ME" <?php if(old('country') == "ME"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Montenegro</option>
					<option value="MS" <?php if(old('country') == "MS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Montserrat</option>
					<option value="MA" <?php if(old('country') == "MA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Morocco</option>
					<option value="MZ" <?php if(old('country') == "MZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Mozambique</option>
					<option value="MM" <?php if(old('country') == "MM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Myanmar</option>
					<option value="NA" <?php if(old('country') == "NA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Namibia</option>
					<option value="NR" <?php if(old('country') == "NR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Nauru</option>
					<option value="NP" <?php if(old('country') == "NP"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Nepal</option>
					<option value="NL" <?php if(old('country') == "NL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Netherlands</option>
					<option value="NC" <?php if(old('country') == "NC"): ?> <?php echo e('selected'); ?> <?php endif; ?> >New Caledonia</option>
					<option value="NZ" <?php if(old('country') == "NZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >New Zealand</option>
					<option value="NI" <?php if(old('country') == "NI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Nicaragua</option>
					<option value="NE" <?php if(old('country') == "NE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Niger</option>
					<option value="NG" <?php if(old('country') == "NG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Nigeria</option>
					<option value="NU" <?php if(old('country') == "NU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Niue</option>
					<option value="NF" <?php if(old('country') == "NF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Norfolk Island</option>
					<option value="MP" <?php if(old('country') == "MP"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Northern Mariana Islands</option>
					<option value="NO" <?php if(old('country') == "NO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Norway</option>
					<option value="OM" <?php if(old('country') == "OM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Oman</option>
					<option value="PK" <?php if(old('country') == "PK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Pakistan</option>
					<option value="PW" <?php if(old('country') == "PW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Palau</option>
					<option value="PS" <?php if(old('country') == "PS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Palestinian Territory, Occupied</option>
					<option value="PA" <?php if(old('country') == "PA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Panama</option>
					<option value="PG" <?php if(old('country') == "PG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Papua New Guinea</option>
					<option value="PY" <?php if(old('country') == "PY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Paraguay</option>
					<option value="PE" <?php if(old('country') == "PE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Peru</option>
					<option value="PH" <?php if(old('country') == "PH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Philippines</option>
					<option value="PN" <?php if(old('country') == "PN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Pitcairn</option>
					<option value="PL" <?php if(old('country') == "PL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Poland</option>
					<option value="PT" <?php if(old('country') == "PT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Portugal</option>
					<option value="PR" <?php if(old('country') == "PR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Puerto Rico</option>
					<option value="QA" <?php if(old('country') == "QA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Qatar</option>
					<option value="RE" <?php if(old('country') == "RE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Réunion</option>
					<option value="RO" <?php if(old('country') == "RO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Romania</option>
					<option value="RU" <?php if(old('country') == "RU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Russian Federation</option>
					<option value="RW" <?php if(old('country') == "RW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Rwanda</option>
					<option value="BL" <?php if(old('country') == "BL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Saint Barthélemy</option>
					<option value="SH" <?php if(old('country') == "SH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Saint Helena, Ascension and Tristan da Cunha</option>
					<option value="KN" <?php if(old('country') == "KN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Saint Kitts and Nevis</option>
					<option value="LC" <?php if(old('country') == "LC"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Saint Lucia</option>
					<option value="MF" <?php if(old('country') == "MF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Saint Martin (French part)</option>
					<option value="PM" <?php if(old('country') == "PM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Saint Pierre and Miquelon</option>
					<option value="VC" <?php if(old('country') == "VC"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Saint Vincent and the Grenadines</option>
					<option value="WS" <?php if(old('country') == "WS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Samoa</option>
					<option value="SM" <?php if(old('country') == "SM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >San Marino</option>
					<option value="ST" <?php if(old('country') == "ST"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Sao Tome and Principe</option>
					<option value="SA" <?php if(old('country') == "SA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Saudi Arabia</option>
					<option value="SN" <?php if(old('country') == "SN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Senegal</option>
					<option value="RS" <?php if(old('country') == "RS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Serbia</option>
					<option value="SC" <?php if(old('country') == "SC"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Seychelles</option>
					<option value="SL" <?php if(old('country') == "SL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Sierra Leone</option>
					<option value="SG" <?php if(old('country') == "SG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Singapore</option>
					<option value="SX" <?php if(old('country') == "SX"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Sint Maarten (Dutch part)</option>
					<option value="SK" <?php if(old('country') == "SK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Slovakia</option>
					<option value="SI" <?php if(old('country') == "SI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Slovenia</option>
					<option value="SB" <?php if(old('country') == "SB"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Solomon Islands</option>
					<option value="SO" <?php if(old('country') == "SO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Somalia</option>
					<option value="ZA" <?php if(old('country') == "ZA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >South Africa</option>
					<option value="GS" <?php if(old('country') == "GS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >South Georgia and the South Sandwich Islands</option>
					<option value="SS" <?php if(old('country') == "SS"): ?> <?php echo e('selected'); ?> <?php endif; ?> >South Sudan</option>
					<option value="ES" <?php if(old('country') == "ES"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Spain</option>
					<option value="LK" <?php if(old('country') == "LK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Sri Lanka</option>
					<option value="SD" <?php if(old('country') == "SD"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Sudan</option>
					<option value="SR" <?php if(old('country') == "SR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Suriname</option>
					<option value="SJ" <?php if(old('country') == "SJ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Svalbard and Jan Mayen</option>
					<option value="SZ" <?php if(old('country') == "SZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Swaziland</option>
					<option value="SE" <?php if(old('country') == "SE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Sweden</option>
					<option value="CH" <?php if(old('country') == "CH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Switzerland</option>
					<option value="SY" <?php if(old('country') == "SY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Syrian Arab Republic</option>
					<option value="TW" <?php if(old('country') == "TW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Taiwan, Province of China</option>
					<option value="TJ" <?php if(old('country') == "TJ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Tajikistan</option>
					<option value="TZ" <?php if(old('country') == "TZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Tanzania, United Republic of</option>
					<option value="TH" <?php if(old('country') == "TH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Thailand</option>
					<option value="TL" <?php if(old('country') == "TL"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Timor-Leste</option>
					<option value="TG" <?php if(old('country') == "TG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Togo</option>
					<option value="TK" <?php if(old('country') == "TK"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Tokelau</option>
					<option value="TO" <?php if(old('country') == "TO"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Tonga</option>
					<option value="TT" <?php if(old('country') == "TT"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Trinidad and Tobago</option>
					<option value="TN" <?php if(old('country') == "TN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Tunisia</option>
					<option value="TR" <?php if(old('country') == "TR"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Turkey</option>
					<option value="TM" <?php if(old('country') == "TM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Turkmenistan</option>
					<option value="TC" <?php if(old('country') == "TC"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Turks and Caicos Islands</option>
					<option value="TV" <?php if(old('country') == "TV"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Tuvalu</option>
					<option value="UG" <?php if(old('country') == "UG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Uganda</option>
					<option value="UA" <?php if(old('country') == "UA"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Ukraine</option>
					<option value="AE" <?php if(old('country') == "AE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >United Arab Emirates</option>
					<option value="GB" <?php if(old('country') == "GB"): ?> <?php echo e('selected'); ?> <?php endif; ?> >United Kingdom</option>
					<option value="US" <?php if(old('country') == "US"): ?> <?php echo e('selected'); ?> <?php endif; ?> >United States</option>
					<option value="UM" <?php if(old('country') == "UM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >United States Minor Outlying Islands</option>
					<option value="UY" <?php if(old('country') == "UY"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Uruguay</option>
					<option value="UZ" <?php if(old('country') == "UZ"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Uzbekistan</option>
					<option value="VU" <?php if(old('country') == "VU"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Vanuatu</option>
					<option value="VE" <?php if(old('country') == "VE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Venezuela, Bolivarian Republic of</option>
					<option value="VN" <?php if(old('country') == "VN"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Viet Nam</option>
					<option value="VG" <?php if(old('country') == "VG"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Virgin Islands, British</option>
					<option value="VI" <?php if(old('country') == "VI"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Virgin Islands, U.S.</option>
					<option value="WF" <?php if(old('country') == "WF"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Wallis and Futuna</option>
					<option value="EH" <?php if(old('country') == "EH"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Western Sahara</option>
					<option value="YE" <?php if(old('country') == "YE"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Yemen</option>
					<option value="ZM" <?php if(old('country') == "ZM"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Zambia</option>
					<option value="ZW" <?php if(old('country') == "ZW"): ?> <?php echo e('selected'); ?> <?php endif; ?> >Zimbabwe</option>
				</select>
			</div>
			
			<div class="form-group">
				<label>Konfirmasi Pendaftaran anda sebagai : </label>
				<div class="custom-control custom-checkbox">
					<input type="checkbox" name="confirm_reg[]" value="email" class="custom-control-input" id="defaultUnchecked">
					<label class="custom-control-label" for="defaultUnchecked">Send me a confirmation email including my username and password.</label>
				</div>
				

				

				
				</div>

				<button type="submit" class="btn btn-primary col-lg-6 col-lg-offset-0">REGISTER</button>
				<button type="submit" class="btn btn-danger col-lg-6 col-lg-offset-0">CANCEL</button>

				
			</form>

		</div>
	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script type="text/javascript">

	$(document).ready(function(){
		$('#div-instansi').hide();
		$('#div-kerja').hide();
		$('#div-no-identitas').hide();
		show_form();
	});

	function show_form(){
		var pekerjaan = $('input[name=category]:checked').val();
		var label = '';
		var unit = '';
		var kerja = '';
		switch (pekerjaan) {
			case 'pns':
				unit = 'Nama Instansi';
				label = 'NIP';
				kerja = 'Unit Kerja';
				$("#unit_kerja").attr('required', ''); 
				$('#div-instansi').show();
				$('#div-no-identitas').show();
				$('#div-kerja').show();
			break;
			case 'dosen':
				unit = 'Nama Universitas';
				label = 'NIP';
			break;
			case 'mhs':
				unit = 'Nama Universitas';
				label = 'NIM';
				$("#unit_kerja").removeAttr('required');
				$('#div-instansi').show();
				$('#div-no-identitas').show();
				$('#div-kerja').hide();
			break;
			case 'umum':
				unit = 'Nama Instansi';
				label = 'NIK';
				kerja = 'Unit Kerja';
				$("#unit_kerja").attr('required', ''); 
				$('#div-instansi').show();
				$('#div-no-identitas').show();
				$('#div-kerja').show();
			break;
			default:
				unit = '';
				label = '';
				kerja = '';
		}

		$('#no-identitas').html(label);
		$('#kerja').html(kerja);
		$('#instansi').html(unit);
	}

	$('input[name=unit_kerja]').keyup(function(){
		var value = $('input[name=unit_kerja]').val();
		var unitInstansi = $('input[name=unit_instansi]').val();
		var html = '';
		if (unitInstansi.indexOf("Dinas Kesehatan") != -1 || unitInstansi.indexOf("Dinkes") != -1 || unitInstansi.indexOf("dinas kesehatan") != -1 || unitInstansi.indexOf("dinkes") != -1) {
			if (value=='') {
				$('#tempat-kerja').html(html);
			}else {
				$.post("<?php echo e(url('api/get_unit')); ?>",{value:value},function(data){
					if(data.status=='success'){
						for (var i = 0; i < data.unit_kerja.length; i++) {
							html+='<a href="javascript:void(0)" onclick="set_unit(\''+data.unit_kerja[i]+'\')">'+data.unit_kerja[i]+'</a><br>';
						}
						$('#tempat-kerja').html(html);
					}
				});
			}
		}
	});

	function set_unit(unit){
		$('input[name=unit_kerja]').val(unit);
		$('#tempat-kerja').html('');
	}

	$(".btn-refresh").click(function(){
		$.ajax({
			type:'GET',
			url:'/refresh_captcha',
			success:function(data){
				$(".captcha span").html(data.captcha);
			}
		});
	});

	function samePass() {
		var password = $('.password').val();
		var confirm_password = $('.confirm_password').val();

		if (password == confirm_password) {
			$('.statusPass').html('');
		}else{
			$('.statusPass').html('the password must be same.');
		}
	}

	$('input[name=password]').keyup(function(){
		samePass();
		var value = $('input[name=password]').val();	
		if (value.length >= 6) {
			$('#pass').hide();
		}else {
			$('#pass').show();
		}
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>