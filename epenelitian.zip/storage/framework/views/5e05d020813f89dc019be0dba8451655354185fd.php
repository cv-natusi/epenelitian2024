<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12">
    <a href="<?php echo e(url('userhome/')); ?>" class="btn btn-info" style="float: right;"><i class="fa fa-backward">  Back</i></a>
	  <div class="section-header">
        <h4 style="font-weight: bold;">Form Permohonan</h4>
        <p>Buat Permohonan Pengajuan Penelitian.</p>
        <hr style="  border: 1px solid DimGray;">
    </div>
</div>
  <div class="col-lg-12 col-md-12">
    <form class="form-horizontal" method="post" action="<?php echo e(route('store_permohonan')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

      <div class="col-lg-12 col-md-12 col-sm-12">
         <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Pilih Jenis Penelitian:</label>
          <div class="col-sm-8">
            <select class="form-control" name="jenis_penelitian_id">
              <option disabled selected style="font-weight: bold;"> .:: Pilih Jenis Penelitian ::. </option>
              <?php $__currentLoopData = $jenis_penelitian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($jp->id_jenis_penelitian); ?>"><?php echo e($jp->nama_jenis); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Judul Penelitian:</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" name="judul_penelitian" placeholder="Masukkan Judul Penelitian yang akan anda buat">
          </div>    
        </div>

         <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Tanggal Awal:</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" name="tgl_awal" placeholder="Tanggal Mulai Penelitian">
          </div>    
        </div>

         <div class="form-group row">
          <label class="col-sm-4 col-form-label"> Tanggal Akhir:</label>
          <div class="col-sm-8">
            <input type="text" class="form-control" name="tgl_akhir" placeholder="Tanggal Selesai Penelitian">
            <label class="custom-control-label" style="color: red;">*sesuai dengan surat rekomendasi dari Bakesbanpol.</label>
          </div>    
        </div>

        <div class="form-group" style="float: right;">
          <button type="submit" class="btn btn-success">SAVE</button>
          <a href="<?php echo e(route('userhome')); ?>" class="btn btn-danger">CANCEL</a>
        </div>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>