<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-12 col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <?php echo e($title); ?>

        </div>
      </div>

      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgPinkCard">
          <div class="iconCard"><i class="fa fa-file-text"></i></div>
          <div class="contenCard">
            <div><?php echo e($accept_count); ?></div>
            <div class="Prof"><a href="<?php echo e(url('data_submission/menu/accept')); ?>" style="color: white;text-decoration: underline;">Submission Accept</a></div>
          </div>
        </div>
        <a href="javascript:void(0)">
        </a>
      </div>

      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgLimeCard">
          <div class="iconCard"><i class="fa fa fa-sticky-note-o"></i></div>
          <div class="contenCard">
            <div><?php echo e($publish_count); ?></div>
            <div class="Prof"><a href="<?php echo e(url('data_submission/menu/publish')); ?>" style="color: white;text-decoration: underline;">Submission Publish</a></div>
          </div>
        </div>
        <a href="javascript:void(0)">
        </a>
      </div>

      <?php if(Auth::getUser()->level==1 || Auth::getUser()->level==2): ?>
      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgOrangeCard">
          <div class="iconCard"><i class="fa fa-user"></i></div>
          <div class="contenCard">
            <div><?php echo e($users_count); ?></div>
            <div class="Prof"><a href="<?php echo e(url('owner/identitas/management_users')); ?>" style="color: white;text-decoration: underline;">Users Active</a></div>
          </div>
        </div>
        <a href="javascript:void(0)">
        </a>
      </div>
      <?php endif; ?>

      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgGreenCard">
          <div class="iconCard"><i class="fa fa-file"></i></div>
          <div class="contenCard">
            <div><?php echo e($pengajuan_count); ?></div>
            <div class="Prof"><a href="<?php echo e(url('data_pengajuan')); ?>" style="color: white;text-decoration: underline;">Pengajuan Diterima</a></div>
          </div>
        </div>
        <a href="javascript:void(0)">
        </a>
      </div>
     <!--  <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgBlueCard">
          <div class="iconCard"><i class="fa fa-file-o"></i></div>
          <div class="contenCard">
            <div><?php echo e($pending_count); ?></div>
            <div class="Prof"><a href="<?php echo e(url('data_submission/menu/pending')); ?>" style="color: white;text-decoration: underline;">Submission Pending</a></div>
          </div>
        </div>
            <a href="javascript:void(0)">
            </a>
      </div>

      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgLightBlueCard">
          <div class="iconCard"><i class="fa fa-file-text-o"></i></div>
          <div class="contenCard">
            <div><?php echo e($review_count); ?></div>
            <div class="Prof"><a href="<?php echo e(url('data_submission/menu/review')); ?>" style="color: white;text-decoration: underline;">Submission in Review</a></div>
          </div>
        </div>
            <a href="javascript:void(0)">
            </a>
      </div>

      <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgRedCard">
          <div class="iconCard"><i class="fa fa-file"></i></div>
          <div class="contenCard">
            <div><?php echo e($revisi_count); ?></div>
            <div class="Prof"><a href="<?php echo e(url('data_submission/menu/revisi')); ?>" style="color: white;text-decoration: underline;">Submission in Revisi</a></div>
          </div>
        </div>
            <a href="javascript:void(0)">
            </a>
      </div> -->



   <!--    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgGreenCard">
          <div class="iconCard"><i class="fa fa-users"></i></div>
          <div class="contenCard">
            <div><?php echo e($author_count); ?></div>
            <div class="Prof">Author</div>
          </div>
        </div>
            <a href="javascript:void(0)">
            </a>
      </div> -->

      <!-- <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6" style="margin-bottom: 10px">
        <div class="panel-body-card bgGreenCard">
          <div class="iconCard"><i class="fa fa-file-text"></i></div>
          <div class="contenCard">
            <div><?php echo e($supplementary_count); ?></div>
            <div class="Prof">File Supplementary</div>
          </div>
        </div>
            <a href="javascript:void(0)">
            </a>
      </div> -->

      <div class="clearfix"></div>
    </div>
  </div>
  <hr>

  <?php
    $pengajuan = DB::table('permohonan')->where('status', 'menunggu')->count();
    $upload = DB::table('doc_pendukung')->where('doc_status', 'pending')->count();
    $sub_accept = DB::table('submissions')->where('status', 'accept')->count();
   ?>

  <!-- <?php if($pengajuan > 0): ?>
  <div class="alert alert-danger" style="font-weight:900;">
    <div class="row">
      <div class="col-md-11">
          Pemberitahuan ! ,
          <br>
          Terdapat (<?php echo e($pengajuan); ?>) Pengajuan baru yang masuk, Mohon Periksa Identitas Pemohon dan Judul Pengajuan tersebut.
      </div>
      <div class="col-md-1">
        <a href="<?php echo e(route('data_pengajuan')); ?>" class="btn btn-success btn-sm float-right"><i class="fa fa-reply"></i></a>
      </div>
    </div>
  </div>
  <?php endif; ?> -->

  <?php if($upload > 0): ?>
  <div class="alert alert-warning" style="font-weight:900;">
    <div class="row">
      <div class="col-md-11">
          Pemberitahuan ! ,
          <br>
         Terdapat (<?php echo e($upload); ?>) beberapa dokumen pendukung yang sudah di upload. Silahkan untuk segera melakukan review dokumen pendukung tersebut untuk di validasi.
      </div>
      <div class="col-md-1">
        <a href="<?php echo e(route('data_pengajuan')); ?>" class="btn btn-success btn-sm float-right"><i class="fa fa-reply"></i></a>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <?php if($sub_accept > 0): ?>
  <div class="alert alert-info">
    <div class="row">
      <div class="col-md-11" style="font-weight:900;">
          Pemberitahuan ! ,         
          <br>
          Terdapat (<?php echo e($sub_accept); ?>) Submission Baru Upload. Periksa details dan publish hasil dari penelitian oleh user peneliti.
      </div>
      <div class="col-md-1">
        <a href="<?php echo e(route('accept')); ?>" class="btn btn-success btn-sm float-right"><i class="fa fa-reply"></i></a>
      </div>
    </div>
  </div>
  <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('owner.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>