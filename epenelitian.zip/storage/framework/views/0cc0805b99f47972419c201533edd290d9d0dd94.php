<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-12 col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <?php echo e($title); ?>

        </div>
        
        <form method='post' action="<?php echo e(route('updatecontact')); ?>">
          <?php echo e(csrf_field()); ?>

            <textarea class="form-control" id="summary-ckeditor" name="contact"><?php echo $identitas->contact; ?></textarea>
        <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        
      </div>
    </div>
  </div>
  <script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
<script>
    CKEDITOR.replace( 'summary-ckeditor' );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('owner.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>