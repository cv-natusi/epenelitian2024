<?php $__env->startSection('content'); ?>

  <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($peng->doc_status == 'tolak'): ?>
      <div class="alert alert-danger" role="alert">
        File Pendukung <b> <?php echo e($peng->nama_jenis); ?> "<?php echo basename($peng->nama_file); ?>"</b> kami <?php echo e($peng->doc_status); ?>, <?php echo e($peng->catatan); ?>. mohon segera upload kembali.<a href="<?php echo e('userhome/up_doc/'.$peng->id_permohonan); ?>" style="font-weight: 900px;"><b>Upload Ulang</b></a>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  	<?php if($per->surat_ijin == 'belum di ambil'): ?>
    	<div class="alert alert-danger" role="alert">
    		Surat ijin penelitian dengan judul <b>"<?php echo e($per->judul_penelitian); ?>"</b> sudah bisa di ambil <a href="<?php echo e('userhome/pernyataan/'.$per->id_permohonan); ?>"><b>...Detail</b></a>
    	</div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <div class="col-lg-12 col-md-12 tbRes">
    <div class="col-lg-12">
      <a href="<?php echo e(url('userhome/create')); ?>" class="btn btn-sm btn-primary">Tambah Pengajuan</a>
      <div class="clearfix" style="margin-bottom: 10px"></div>
      <table class="table">
        <thead>
          <tr>
            <th width="5%">No</th>
            <th>Judul</th>
            <th width="5%">Aksi</th>
            <th width="5%">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if($permohonan->count()!=0): ?>
            <?php
            $no = 1;
            ?>
            <?php $__currentLoopData = $permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mohon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($mohon->judul_penelitian); ?></td>
                <td>
                  <?php
                  switch ($mohon->status) {
                    case 'Pending':
                      $doc = App\Doc_Pendukung::where('permohonan_id',$mohon->id_permohonan)->get();
                      if($doc->count()!=0){
                        $aksi = '<a href="'.url('userhome/up_doc/'.$mohon->id_permohonan).'" class="btn btn-sm btn-primary">Detail file pendukung</a>';
                      }else{
                        $aksi = '<a href="'.url('userhome/up_doc/'.$mohon->id_permohonan).'" class="btn btn-sm btn-primary">Upload berkas pendukung</a>';
                      }
                      break;

                    default:
                      $aksi = '';
                      break;
                  }
                  echo $aksi;
                  ?>
                </td>
                <td><?php echo e($mohon->status); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <tr>
              <td colspan="3" style="text-align: center">..:: Belum ada pengajuan ::..</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
	  <h3 style="font-weight: bold;">Cek Plagiarism</h3>
		  <p>
			<?php if(Session::get('bahasa') == 'indonesia'): ?>
            <?php echo $bahasa['bahasa16']->indonesia; ?>

          <?php else: ?>
            <?php echo $bahasa['bahasa16']->inggris; ?>

          <?php endif; ?>
          <a href="https://smallseotools.com/plagiarism-checker/" class="btn btn-info btn-xs"><i class="fa fa-link"></i> <b>Klik disini</b></a>
          <!-- <a href="https://smallseotools.com/plagiarism-checker/" style="color: red;text-decoration: underline;">click here.</a></p> -->
	<hr style="  border: 1px solid DimGray;">
	<h3 style="font-weight: bold;">My Account</h3>
	  	<li><a href="<?php echo e(route('edit_profil')); ?>">Edit My Profile</a></li>
	  	<li><a href="<?php echo e(route('update_password')); ?>">Change My Password</a></li>
	  	<li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
	<hr style="  border: 1px solid DimGray;">
  </div>
  <script type="text/javascript">
  	var lbrRes = $('.tbRes').width();
  	$('.tblRes').attr('style','max-width:'+lbrRes+'px;overflow-x:scroll;')
  	console.log(lbrRes);
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>