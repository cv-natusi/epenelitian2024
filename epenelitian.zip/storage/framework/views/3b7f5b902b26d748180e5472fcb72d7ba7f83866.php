<?php $__env->startSection('content'); ?>
<style>
.btnabout{
  background-image: linear-gradient(#7ea3d5, #547AB8 , #579BD4);
  font-weight: bold;
}
</style>
  <div class="col-lg-12 col-md-12">
    <div class="list-group liAbJournal">
        <h4><Button class="btn btnabout">
          <?php if(Session::get('bahasa') == 'indonesia'): ?>
            <?php echo $bahasa['bahasa54']->indonesia; ?>

          <?php else: ?>
            <?php echo $bahasa['bahasa54']->inggris; ?>

          <?php endif; ?>
        </Button></h4>
          <li><a href="about/sop">
            <i class="fa fa-tags"></i>
            <?php if(Session::get('bahasa') == 'indonesia'): ?>
              <?php echo $bahasa['bahasa55']->indonesia; ?>

            <?php else: ?>
              <?php echo $bahasa['bahasa55']->inggris; ?>

            <?php endif; ?></a>
          </li>
          <li><a href="about/contact">
            <i class="fa fa-list"></i>
            <?php if(Session::get('bahasa') == 'indonesia'): ?>
              <?php echo $bahasa['bahasa56']->indonesia; ?>

            <?php else: ?>
              <?php echo $bahasa['bahasa56']->inggris; ?>

            <?php endif; ?>
             <span style="font-weight: bold; color: red;"> <i class="fa fa-download"></i> Download contoh File Orsinilitas disini.</span></a>
          </li>
    </div>
    <div class="text-center" style="margin: 20px 0px;">
      <h3 style="font-weight: bold;">Alur Penelitian</h3>
      <hr>
      <iframe src="<?php echo e(url('uploads/files/alur.pdf')); ?>" width="85%" height="700px"></iframe>
      
    </div><br>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>