<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="panel panel-primary">
      <div class="panel-heading">
        <?php echo e($title); ?>

      </div>
    </div>
  </div>
</div>
<a href="" class="btn btn-primary">BACK</a>
<iframe src="<?php echo e(url('/')); ?>/uploads/file_submissions/<?php echo e($id->file_submission); ?>" type="application/pdf" width="100%" height="580px">
  This browser does not support PDFs. Please download the PDF to view it: Download PDF
  </iframe>