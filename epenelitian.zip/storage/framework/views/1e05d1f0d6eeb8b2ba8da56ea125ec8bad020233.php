<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-12 col-md-12">
    <a href="<?php echo e(url('userhome/')); ?>" class="btn btn-info" style="float: right;"><i class="fa fa-backward">  Back</i></a>
	  <div class="section-header">
        <h4 style="font-weight: bold;">Penelitian <b>"<?php echo e($per->judul_penelitian); ?>"</b></h4>
        <hr style="  border: 1px solid DimGray;">
    </div>
</div>
<div class="col-lg-12 col-md-12">
	<div class="text-muted">
		<strong>
            Surat ijin penelitian sudah bisa di ambil:<br>
        </strong><br>        
	</div>
	<form action="<?php echo e(url('userhome/confirm_penelitian')); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		<div class="form-group">
			<label>Estimasi Waktu Penelitian Selesai</label>
			<input type="hidden" name="id" value="<?php echo e($per->id_permohonan); ?>">
			<input id="dtp" name="estimasi" class="form-control" required="" placeholder="exp: 2019-12-19">
		</div>
		<div class="alert alert-warning" style="text-align: justify;">
			<p class="text-center"><b>PERNYATAAN</b></p>
			<input type="checkbox" name="agree" required="">
			Saya bersedia upload/ submiting hasil penelitian akhir (Bab1-7), maksimal 1 bulan setelah penelitian selesai. Jika tidak, maka saya bersedia tidak diijinkan melakukan penelitian kembali di Kab. Sidoarjo
		</div>
		<button type="submit" class="btn btn-success">Konfirmasi</button>
	</form>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
		$(function(){
        $( "#dtp" ).datepicker({
         dateFormat:'yy-mm-dd',
         changeMonth: true,
         changeYear: true,
         yearRange:'2015:2065'
	     });
	    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>