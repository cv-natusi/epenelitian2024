<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12">
  <a href="<?php echo e(url('about/')); ?>" class="btn btn-primary btn-sm" style="float: right;font-size:12px;"><i class="fa fa-backward"> Kembali</i></a>
  <h1>Tata cara</h1>
   <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
            <b>
             <?php if(Session::get('bahasa') == 'indonesia'): ?>
                <?php echo $bahasa['bahasa55']->indonesia; ?>

              <?php else: ?>
                <?php echo $bahasa['bahasa55']->inggris; ?>

              <?php endif; ?>
            </b>
        </h4>
      </div>
      <div class="panel-body">
          <iframe src="<?php echo e(url('/')); ?>/uploads/files/Doc5.pdf" type="application/pdf" width="100%" height="680px">This browser does not support PDFs. Please download the PDF to view it: Download PDF</iframe>
        </br>
          <iframe src="<?php echo e(url('/')); ?>/uploads/files/alur.pdf" type="application/pdf" width="100%" height="750px">This browser does not support PDFs. Please download the PDF to view it: Download PDF</iframe>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
    $('.panel-collapse').on('show.bs.collapse', function () {
      $(this).siblings('.panel-heading').addClass('active');
    });

    $('.panel-collapse').on('hide.bs.collapse', function () {
      $(this).siblings('.panel-heading').removeClass('active');
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>