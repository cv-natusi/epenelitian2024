<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-12 col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <?php echo e($title); ?>

        </div>
        <div class="panel-body">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th width="40%">Nama Menu Indonesia</th>
                <th width="40%">Nama Menu Inggris</th>
                <th width="20%">View</th>
              </tr>
            </thead>
            <tbody>
              <?php if(count($menus)!=0): ?>
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($menu->id_menu!=8 && $menu->id_menu!=6): ?>
                  <tr>
                    <td><?php echo e($menu->nama_menu); ?></td>
                    <td><?php echo e($menu->name_menu); ?></td>
                    <td>
                      <a href="<?php echo e(url($menu->url)); ?>" target="_blank" class="btn btn-default">
                        <i class="fa fa-eye"></i>
                      </a>
                      <a href="javascript:void(0)" onclick="form('<?php echo e($menu->id_menu); ?>')" class="btn btn-success">
                        <i class="fa fa-edit"></i>
                      </a>
                    </td>
                  </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <div class="modal-dialog">

  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
  <script type="text/javascript">
    function form(id){
      $.post("<?php echo e(route('form_menu_owner')); ?>",{id:id},function(data){
        if(data.status=='success'){
          $('.modal-dialog').html(data.content);
        }
      });
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('owner.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>