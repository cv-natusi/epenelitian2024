<?php $__env->startSection('content'); ?>
  <div class="col-lg-12 col-md-12">
      <a href="<?php echo e(url('userhome/archive/')); ?>" class="btn btn-info btn-xs" style="float: right; font-size:15px;"><i class="fa fa-backward"> Back</i></a>
      <h4 style="font-weight: bold; color: #4682B4;">Active Submission</h4>
      <hr style="  border: 1px solid DimGray;">
      <table class="table">
        <tbody>
            <tr>
              <th>Original Filename </th>
              <td> : <?php echo e($submission->original_filename); ?></td>           
            </tr>
            <tr>
              <th>File Size</th>
              <td> : <?php echo e($submission->file_size); ?></td>            
            </tr>
            <tr>
              <th>Title</th>
              <td> : <?php echo e($submission->title); ?></td>            
            </tr>
            <tr>
              <th>Language</th>
              <td> : <?php echo e($submission->lang); ?></td>            
            </tr>
            <tr>
              <th>Abstract</th>
              <td> : <?php echo e($submission->abstract); ?></td>           
            </tr>
            <tr>
              <th>Agencies</th>
              <td> : <?php echo e($submission->agencies); ?></td>            
            </tr>
            <tr>
              <th>References</th>
              <td> : <?php echo e($submission->references); ?></td>            
            </tr>
             <tr>
              <th>Author Comments</th>
              <td> : <?php echo $submission->comments; ?></td>            
            </tr>              
        </tbody>
      </table>
      
      <h4 style="font-weight: bold; color: #4682B4;">Status</h4>
      <hr style="  border: 1px solid DimGray;">
      <table class="table">
        <tbody>
            <tr>
              <th>Status</th>
              <td> : <?php echo e($submission->status); ?></td>           
            </tr>
            <tr>
              <th>Created</th>
              <td> : <?php echo e($submission->created_at); ?></td>            
            </tr>
            <tr>
              <th>Last Modified</th>
              <td> : <?php echo e($submission->updated_at); ?></td>            
            </tr>                    
        </tbody>
      </table>

      <h4 style="font-weight: bold; color: #4682B4;">Author Submission</h4>
      <hr style="  border: 1px solid DimGray;">
      <table class="table">
        <tbody>
        <?php if(!empty($submission->author_submit)): ?>
          <?php $__currentLoopData = $submission->author_submit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th>first Name</th>
              <td> : <?php echo e($aut->first_name); ?></td>           
            </tr>
            <tr>
              <th>Email</th>
              <td> : <?php echo e($aut->email); ?></td>            
            </tr>
            <tr>
              <th>Orcid ID</th>
              <td> : <?php echo e($aut->id_orcid); ?></td>            
            </tr>
            <tr>
              <th>Affiliation</th>
              <td> : <?php echo e($aut->affiliation); ?></td>            
            </tr>
            <tr>
              <th>Interest</th>
              <td> : <?php echo $aut->interest; ?></td>           
            </tr>
            <tr>
              <th>Bio</th>
              <td> : <?php echo $aut->bio; ?></td>            
            </tr>
            <tr>
              <td colspan="2">
              <hr style="  border: 1px solid DimGray;">                              
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
      </table>

      <h4 style="font-weight: bold; color: #4682B4;">Supplementary File</h4>
      <hr style="  border: 1px solid DimGray;">
      <table class="table">
        <tbody>
            <?php if(!empty($submission->supplementary)): ?>
              <?php $__currentLoopData = $submission->supplementary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th>Title</th>
                <td> : <?php echo e($sup->title); ?></td>           
              </tr>
              <tr>
                <th>File</th>
                <td> : <?php echo e($sup->file); ?></td>            
              </tr>
              <tr>
                <th>Creator</th>
                <td> : <?php echo e($sup->creator); ?></td>            
              </tr>
              <tr>
                <th>Type</th>
                <td> : <?php echo e($sup->type); ?></td>            
              </tr>
              <tr>
                <th>Descriptions</th>
                <td> : <?php echo e($sup->description); ?></td>           
              </tr> 
              <tr>
                <td colspan="2">
                <hr style="  border: 1px solid DimGray;">                              
                </td>
              </tr>   
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
            <?php endif; ?>                      
        </tbody>
      </table>  
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>