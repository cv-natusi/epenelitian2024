<?php $__env->startSection('content'); ?>

  <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($peng->doc_status == 'Tolak'): ?>
      <div class="alert alert-danger" role="alert">
        File Pendukung <b> <?php echo e($peng->nama_jenis); ?> "<?php echo basename($peng->nama_file); ?>"</b> kami <?php echo e($peng->doc_status); ?>, <?php echo e($peng->catatan); ?>. mohon segera upload kembali.<a href="<?php echo e('userhome/up_doc/'.$peng->id_permohonan); ?>" style="font-weight: 900px;"><b>Upload Ulang</b></a>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  	<?php if($per->surat_ijin == 'belum di ambil'): ?>
    	<div class="alert alert-danger" role="alert">
    		Surat ijin penelitian dengan judul <b>"<?php echo e($per->judul_penelitian); ?>"</b> sudah bisa di ambil <a href="<?php echo e('userhome/pernyataan/'.$per->id_permohonan); ?>"><b>...Detail</b></a>
    	</div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <div class="col-lg-12 col-md-12 tbRes">
    <div class="col-lg-12">
      <a href="<?php echo e(url('userhome/create')); ?>" class="btn btn-sm btn-primary">Tambah Pengajuan</a>
      <div class="clearfix" style="margin-bottom: 10px"></div>
      <table class="table">
        <thead>
          <tr>
            <th width="5%">No</th>
            <th>Judul</th>
            <th>Tempat Penelitian</th>
            <th width="10%">Estimasi Surat</th>
            <th width="10%">Pengambilan Surat</th>
            <th width="5%">Aksi</th>
            <th width="5%">Status Permohonan</th>
            <th width="5%">Hasil</th>
            <th width="5%">Status Hasil</th>
          </tr>
        </thead>
        <tbody>
          <?php if($permohonan->count()!=0): ?>
            <?php
            $no = 1;
            ?>
            <?php $__currentLoopData = $permohonan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mohon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($mohon->judul_penelitian); ?></td>
                <td>
                  <?php
                  $tempat = explode("|",$mohon->tempat_penelitian);
                  if(count($tempat)>1){
                    echo '<ol>';
                    for ($i=0; $i < count($tempat); $i++) {
                      echo '<li>'.$tempat[$i].'</li>';
                    }
                    echo '</ol>';
                  }else{
                    if(count($tempat)>0){
                      echo $tempat[0];
                    }else{
                      echo '';
                    }
                  }
                  ?>
                </td>
                <td><?php echo e($mohon->estimasi_waktu); ?></td>
                <td><?php echo e($mohon->tgl_ambil); ?></td>
                <td>
                  <?php
                  $judul = 'Upload Persyaratan';
                  if($mohon->status!='Pending'){
                    $judul = 'Detail file pendukung';
                  }
                  $aksi = '<a href="'.url('userhome/up_doc/'.$mohon->id_permohonan).'" class="btn btn-sm btn-primary">'.$judul.'</a>';
                  echo $aksi;
                  ?>
                </td>
                <td><?php echo e($mohon->status); ?></td>
                <td>
                  <?php
                  if($mohon->tgl_ambil!='' || $mohon->tgl_ambil!=null){
                    echo '<a href="'.url('/upload-hasil/penelitian/'.$mohon->id_permohonan).'" class="btn btn-sm btn-primary">Upload hasil penelitian</a>';
                  }
                  ?>
                </td>
                <td><?php echo e($mohon->status_hasil); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <tr>
              <td colspan="7" style="text-align: center">..:: Belum ada pengajuan ::..</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
    <div class="col-lg-12 col-md-12">
      <?php echo $permohonan->render(); ?>

    </div>
	  <h3 style="font-weight: bold;">Cek Plagiarism</h3>
		  <p>
			<?php if(Session::get('bahasa') == 'indonesia'): ?>
            <?php echo $bahasa['bahasa16']->indonesia; ?>

          <?php else: ?>
            <?php echo $bahasa['bahasa16']->inggris; ?>

          <?php endif; ?>
          <a href="https://smallseotools.com/plagiarism-checker/" class="btn btn-info btn-xs"><i class="fa fa-link"></i> <b>Klik disini</b></a>
          <!-- <a href="https://smallseotools.com/plagiarism-checker/" style="color: red;text-decoration: underline;">click here.</a></p> -->
	<hr style="  border: 1px solid DimGray;">
	<h3 style="font-weight: bold;">My Account</h3>
	  	<li><a href="<?php echo e(route('edit_profil')); ?>">Edit My Profile</a></li>
	  	<li><a href="<?php echo e(route('update_password')); ?>">Change My Password</a></li>
	  	<li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
	<hr style="  border: 1px solid DimGray;">
  </div>
  <script type="text/javascript">
  	var lbrRes = $('.tbRes').width();
  	$('.tblRes').attr('style','max-width:'+lbrRes+'px;overflow-x:scroll;')
  	console.log(lbrRes);
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>