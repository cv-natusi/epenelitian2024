<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-lg-12 col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <?php echo e($title); ?>

        </div>
        <div class="panel-body">
          <form class="" action="<?php echo e(route('simpan_identitas_owner')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="col-lg-6 col-md-6" style="padding: 0px">
              <div class="form-group">
                <label class="col-lg-4 col-md-4">Nama Web</label>
                <div class="col-lg-8 col-md-8">
                  <input autocomplete="off" type="text" class="form-control" name="nama_web" value="<?php echo e($identitas->nama_web); ?>">
                </div>
              </div>
              <div class="clearfix" style="margin-bottom: 10px"></div>
              <div class="form-group">
                <label class="col-lg-4 col-md-4">Alamat</label>
                <div class="col-lg-8 col-md-8">
                  <textarea name="alamat" class="form-control"><?php echo e($identitas->alamat); ?></textarea>
                </div>
              </div>
              <div class="clearfix" style="margin-bottom: 10px"></div>
              <div class="form-group">
                <label class="col-lg-4 col-md-4">Email</label>
                <div class="col-lg-8 col-md-8">
                  <input autocomplete="off" type="text" class="form-control" name="email" value="<?php echo e($identitas->email); ?>">
                </div>
              </div>
              <div class="clearfix" style="margin-bottom: 10px"></div>
              <div class="form-group">
                <label class="col-lg-4 col-md-4">Telepon</label>
                <div class="col-lg-8 col-md-8">
                  <input autocomplete="off" type="text" class="form-control" name="telepon" value="<?php echo e($identitas->telepon); ?>">
                </div>
              </div>
              <div class="clearfix" style="margin-bottom: 10px"></div>
              <div class="form-group">
                <label class="col-lg-4 col-md-4">Fax</label>
                <div class="col-lg-8 col-md-8">
                  <input autocomplete="off" type="text" class="form-control" name="fax" value="<?php echo e($identitas->fax); ?>">
                </div>
              </div>
              <div class="clearfix" style="margin-bottom: 10px"></div>
            </div>
            <div class="clearfix" style="margin-bottom: 10px"></div>
            <div class="col-lg-12 col-md-12">
              <input type="submit" name="" value="Simpan" class="form-control btn btn-primary">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('owner.master.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>