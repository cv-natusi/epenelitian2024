<div class="modal fade" id="detail-dialog" tabindex="-1" role="dialog" aria-labelledby="product-detail-dialog">
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">
      <div class="modal-header" style="width: 100%">
          Dokumen lengkap Pengajuan Penelitian
        <span style="float:right"><a data-dismiss="modal" onclick="closeModal()">Close</a></span>
      </div>
      <div class="modal-body">
        <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
          <h4 style="font-weight: bold; color: #4682B4;">Kelengkapan Dokumen</h4>
          <hr style="  border: 1px solid DimGray;">
        <?php if(!empty($pengajuan)): ?>
          <div class="form-group m-t-0 m-b-25">
            <button class="accordion1 btn btn-default btn-doc">Proposal Penelitian</button>
            <div class="panel-accordion1" style="display: none;">
              <?php if($pengajuan->upload_proposal_penelitian != ''): ?>
                <?php if(file_exists('uploads/file_upload_persyaratan/'.$pengajuan->upload_proposal_penelitian)): ?>
                  <?php $ext = explode('.',$pengajuan->upload_proposal_penelitian); ?>
                  <?php if($ext[1]=='pdf' || $ext[1]=='PDF'): ?>
                    <iframe src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_proposal_penelitian); ?>" width="100%" height="550px"></iframe>
                  <?php else: ?>
                    <img src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_proposal_penelitian); ?>" alt="" style="width: 100%">
                  <?php endif; ?>
                <?php else: ?>
                  <?php echo $status = 'Tidak ada file'; ?>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==2 || $pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-6 col-md-6">
                      <b>No Surat</b> : <?php echo e($pengajuan->no_surat); ?>

                    </div>
                    <div class="col-lg-6 col-md-6">
                      <b>Tanggal Surat</b> : <?php echo e(App\Http\Libraries\Formatter::tanggal_indo($pengajuan->tanggal_surat)); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-12 col-md-6">
                      <b>Penandatangan Surat Pengantar</b> : <?php echo e($pengajuan->jabatan_pj .' ('. $pengajuan->nama_pj .')'); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
            <button class="accordion2 btn btn-default btn-doc">Surat Pengantar dari Universitas/Instansi Lain</button>
            <div class="panel-accordion2" style="display: none;">
              <?php if($pengajuan->upload_surat_pengantar != ''): ?>
                <?php if(file_exists('uploads/file_upload_persyaratan/'.$pengajuan->upload_surat_pengantar)): ?>
                  <?php $ext = explode('.',$pengajuan->upload_surat_pengantar); ?>
                  <?php if($ext[1]=='pdf' || $ext[1]=='PDF'): ?>
                    <iframe src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_surat_pengantar); ?>" width="100%" height="550px"></iframe>
                  <?php else: ?>
                    <img src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_surat_pengantar); ?>" alt="" style="width: 100%">
                  <?php endif; ?>
                <?php else: ?>
                  <?php echo $status = 'Tidak ada file'; ?>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==2 || $pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-6 col-md-6">
                      <b>No Surat</b> : <?php echo e($pengajuan->no_surat); ?>

                    </div>
                    <div class="col-lg-6 col-md-6">
                      <b>Tanggal Surat</b> : <?php echo e(App\Http\Libraries\Formatter::tanggal_indo($pengajuan->tanggal_surat)); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-12 col-md-6">
                      <b>Penandatangan Surat Pengantar</b> : <?php echo e($pengajuan->jabatan_pj .' ('. $pengajuan->nama_pj .')'); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
            <button class="accordion3 btn btn-default btn-doc">Surat Rekomendasi Bakesbangpol Kabupaten Sidoarjo</button>
            <div class="panel-accordion3" style="display: none;">
              <?php if($pengajuan->upload_surat_rekomendasi != ''): ?>
                <?php if(file_exists('uploads/file_upload_persyaratan/'.$pengajuan->upload_surat_rekomendasi)): ?>
                  <?php $ext = explode('.',$pengajuan->upload_surat_rekomendasi); ?>
                  <?php if($ext[1]=='pdf' || $ext[1]=='PDF'): ?>
                    <iframe src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_surat_rekomendasi); ?>" width="100%" height="550px"></iframe>
                  <?php else: ?>
                    <img src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_surat_rekomendasi); ?>" alt="" style="width: 100%">
                  <?php endif; ?>
                <?php else: ?>
                  <?php echo $status = 'Tidak ada file'; ?>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==2 || $pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-6 col-md-6">
                      <b>No Surat</b> : <?php echo e($pengajuan->no_surat); ?>

                    </div>
                    <div class="col-lg-6 col-md-6">
                      <b>Tanggal Surat</b> : <?php echo e(App\Http\Libraries\Formatter::tanggal_indo($pengajuan->tanggal_surat)); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-12 col-md-6">
                      <b>Penandatangan Surat Pengantar</b> : <?php echo e($pengajuan->jabatan_pj .' ('. $pengajuan->nama_pj .')'); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
            <button class="accordion4 btn btn-default btn-doc">Surat Pernyataan Peneliti</button>
            <div class="panel-accordion4" style="display: none;">
              <?php if($pengajuan->upload_surat_pernyataan != ''): ?>
                <?php if(file_exists('uploads/file_upload_persyaratan/'.$pengajuan->upload_surat_pernyataan)): ?>
                  <?php $ext = explode('.',$pengajuan->upload_surat_pernyataan); ?>
                  <?php if($ext[1]=='pdf' || $ext[1]=='PDF'): ?>
                    <iframe src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_surat_pernyataan); ?>" width="100%" height="550px"></iframe>
                  <?php else: ?>
                    <img src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_surat_pernyataan); ?>" alt="" style="width: 100%">
                  <?php endif; ?>
                <?php else: ?>
                  <?php echo $status = 'Tidak ada file'; ?>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==2 || $pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-6 col-md-6">
                      <b>No Surat</b> : <?php echo e($pengajuan->no_surat); ?>

                    </div>
                    <div class="col-lg-6 col-md-6">
                      <b>Tanggal Surat</b> : <?php echo e(App\Http\Libraries\Formatter::tanggal_indo($pengajuan->tanggal_surat)); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-12 col-md-6">
                      <b>Penandatangan Surat Pengantar</b> : <?php echo e($pengajuan->jabatan_pj .' ('. $pengajuan->nama_pj .')'); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
            <button class="accordion5 btn btn-default btn-doc">Surat Kesediaan Pemegang Program Instansi yang akan diteliti</button>
            <div class="panel-accordion5" style="display: none;">
              <?php if($pengajuan->upload_surat_kesediaan != ''): ?>
                <?php if(file_exists('uploads/file_upload_persyaratan/'.$pengajuan->upload_surat_kesediaan)): ?>
                  <?php $ext = explode('.',$pengajuan->upload_surat_kesediaan); ?>
                  <?php if($ext[1]=='pdf' || $ext[1]=='PDF'): ?>
                    <iframe src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_surat_kesediaan); ?>" width="100%" height="550px"></iframe>
                  <?php else: ?>
                    <img src="<?php echo e(url('/')); ?>/uploads/file_upload_persyaratan/<?php echo e($pengajuan->upload_surat_kesediaan); ?>" alt="" style="width: 100%">
                  <?php endif; ?>
                <?php else: ?>
                  <?php echo $status = 'Tidak ada file'; ?>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==2 || $pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-6 col-md-6">
                      <b>No Surat</b> : <?php echo e($pengajuan->no_surat); ?>

                    </div>
                    <div class="col-lg-6 col-md-6">
                      <b>Tanggal Surat</b> : <?php echo e(App\Http\Libraries\Formatter::tanggal_indo($pengajuan->tanggal_surat)); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
                <?php if($pengajuan->jenis_file==3): ?>
                  <div class="col-lg-12 col-md-12">
                    <div class="col-lg-12 col-md-6">
                      <b>Penandatangan Surat Pengantar</b> : <?php echo e($pengajuan->jabatan_pj .' ('. $pengajuan->nama_pj .')'); ?>

                    </div>
                  </div>
                  <div class="clearfix"></div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
            <br><br>
            <?php if(Auth::getUser()->level==1): ?>
              <?php if($pengajuan->acc_admin == 'Terima'): ?>
                <a href="javascript:void(0)" class="btn btn-info"><i class="fa fa-check"><span> Dokumen sudah Diterima</span></i></a>
              <?php endif; ?>
              <?php if($pengajuan->acc_admin == 'Tolak'): ?>
                <a href="javascript:void(0)" class="btn btn-danger"><i class="fa fa-times"><span> Dokumen Ditolak</span></i></a>
              <?php endif; ?>
              <?php if($pengajuan->acc_admin=='Menunggu'): ?>
                <span class="panel-btn-waiting<?php echo e($pengajuan->id_item_permohonan); ?>">
                  <fieldset class="form-group">
                    <label>Catatan</label>
                    <textarea name="catatan" id="catatan" class="form-control">-</textarea>
                  </fieldset>
                  <a href="javascript:void(0)" onclick="approve('<?php echo e($pengajuan->id_item_permohonan); ?>','Terima')" class="btn btn-success btn-approve" id="btn-approve">
                    <i class="fa fa-check"><span> Terima</span></i>
                  </a>
                  <a href="javascript:void(0)" onclick="approve('<?php echo e($pengajuan->id_item_permohonan); ?>','Tolak')" class="btn btn-danger">
                    <i class="fa fa-times"><span> Tolak</span></i>
                  </a>
                </span>
              <?php endif; ?>
            <?php elseif(Auth::getUser()->level==2): ?>
              <?php if($pengajuan->acc_kasi == 'Terima'): ?>
                <a href="javascript:void(0)" class="btn btn-info"><i class="fa fa-check"><span> Dokumen sudah Diterima</span></i></a>
              <?php endif; ?>
              <?php if($pengajuan->acc_kasi == 'Tolak'): ?>
                <a href="javascript:void(0)" class="btn btn-danger"><i class="fa fa-times"><span> Dokumen Ditolak</span></i></a>
              <?php endif; ?>
              <?php if($pengajuan->acc_kasi=='Menunggu'): ?>
                <span class="panel-btn-waiting<?php echo e($pengajuan->id_item_permohonan); ?>">
                  <fieldset class="form-group">
                    <label>Catatan</label>
                    <textarea name="catatan" id="catatan" class="form-control">-</textarea>
                  </fieldset>
                  <a href="javascript:void(0)" onclick="approve('<?php echo e($pengajuan->id_item_permohonan); ?>','Terima')" class="btn btn-success btn-approve" id="btn-approve">
                    <i class="fa fa-check"><span> Terima</span></i>
                  </a>
                  <a href="javascript:void(0)" onclick="approve('<?php echo e($pengajuan->id_item_permohonan); ?>','Tolak')" class="btn btn-danger">
                    <i class="fa fa-times"><span> Tolak</span></i>
                  </a>
                </span>
              <?php endif; ?>
            <?php elseif(Auth::getUser()->level==4): ?>
              <?php if($pengajuan->acc_kabid == 'Terima'): ?>
                <a href="javascript:void(0)" class="btn btn-info"><i class="fa fa-check"><span> Dokumen sudah Diterima</span></i></a>
              <?php endif; ?>
              <?php if($pengajuan->acc_kabid == 'Tolak'): ?>
                <a href="javascript:void(0)" class="btn btn-danger"><i class="fa fa-times"><span> Dokumen Ditolak</span></i></a>
              <?php endif; ?>
              <?php if($pengajuan->acc_kabid=='Menunggu'): ?>
                <span class="panel-btn-waiting<?php echo e($pengajuan->id_item_permohonan); ?>">
                  <fieldset class="form-group">
                    <label>Catatan</label>
                    <textarea name="catatan" id="catatan" class="form-control">-</textarea>
                  </fieldset>
                  <a href="javascript:void(0)" onclick="approve('<?php echo e($pengajuan->id_item_permohonan); ?>','Terima')" class="btn btn-success btn-approve" id="btn-approve">
                    <i class="fa fa-check"><span> Terima</span></i>
                  </a>
                  <a href="javascript:void(0)" onclick="approve('<?php echo e($pengajuan->id_item_permohonan); ?>','Tolak')" class="btn btn-danger">
                    <i class="fa fa-times"><span> Tolak</span></i>
                  </a>
                </span>
              <?php endif; ?>
            <?php elseif(Auth::getUser()->level==5): ?>
              <?php if($pengajuan->acc_kadin == 'Terima'): ?>
                <a href="javascript:void(0)" class="btn btn-info"><i class="fa fa-check"><span> Dokumen sudah Diterima</span></i></a>
              <?php endif; ?>
              <?php if($pengajuan->acc_kadin == 'Tolak'): ?>
                <a href="javascript:void(0)" class="btn btn-danger"><i class="fa fa-times"><span> Dokumen Ditolak</span></i></a>
              <?php endif; ?>
              <?php if($pengajuan->acc_kadin=='Menunggu'): ?>
                <span class="panel-btn-waiting<?php echo e($pengajuan->id_item_permohonan); ?>">
                  <fieldset class="form-group">
                    <label>Catatan</label>
                    <textarea name="catatan" id="catatan" class="form-control">-</textarea>
                  </fieldset>
                  <a href="javascript:void(0)" onclick="approve('<?php echo e($pengajuan->id_item_permohonan); ?>','Terima')" class="btn btn-success btn-approve" id="btn-approve">
                    <i class="fa fa-check"><span> Terima</span></i>
                  </a>
                  <a href="javascript:void(0)" onclick="approve('<?php echo e($pengajuan->id_item_permohonan); ?>','Tolak')" class="btn btn-danger">
                    <i class="fa fa-times"><span> Tolak</span></i>
                  </a>
                </span>
              <?php endif; ?>
            <?php else: ?>
            <?php endif; ?>
          </div>
        <?php endif; ?>
        </div>
      </div>
      <div class="clearfix" style='padding-bottom:20px'></div>
    </div>
  </div>
</div>
<script type="text/javascript">
  $().ready(function() {
    // validate the comment form when it is submitted
    $("#commentForm").validate();
  });

    var onLoad = (function() {
        $('#detail-dialog').find('.modal-dialog').css({
            'width'     : '60%'
        });
        $('#detail-dialog').modal('show');
    })();

    $('#detail-dialog').on('hidden.bs.modal', function () {
        $('.modal-dialog').html('');
    });

    // var acc = document.getElementsByClassName("accordion");

    // for (var i = 0; i < acc.length; i++) {
    //   acc[i].addEventListener("click", function() {
    //     this.classList.toggle("active");
    //     var panel = this.nextElementSibling;
    //     if (panel.style.display === "block") {
    //       panel.style.display = "none";
    //     } else {
    //       panel.style.display = "block";
    //     }
    //   });
    // }

    var acc1 = document.getElementsByClassName("accordion1");

    for (var i = 0; i < acc1.length; i++) {
      acc1[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
          panel.style.display = "none";
        } else {
          panel.style.display = "block";
        }
      });
    }

    var acc2 = document.getElementsByClassName("accordion2");

    for (var i = 0; i < acc2.length; i++) {
      acc2[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
          panel.style.display = "none";
        } else {
          panel.style.display = "block";
        }
      });
    }

    var acc3 = document.getElementsByClassName("accordion3");

    for (var i = 0; i < acc3.length; i++) {
      acc3[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
          panel.style.display = "none";
        } else {
          panel.style.display = "block";
        }
      });
    }

    var acc4 = document.getElementsByClassName("accordion4");

    for (var i = 0; i < acc4.length; i++) {
      acc4[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
          panel.style.display = "none";
        } else {
          panel.style.display = "block";
        }
      });
    }

    var acc5 = document.getElementsByClassName("accordion5");

    for (var i = 0; i < acc5.length; i++) {
      acc5[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
          panel.style.display = "none";
        } else {
          panel.style.display = "block";
        }
      });
    }
    
   function approve(id_item_permohonan,doc_status) {
      if (doc_status == 'Terima') {
        var ket ='menerima?';
      }else{
        var ket ='menolak?';
      }
      var catatan = $('#catatan').val();
      swal({
       title:"Apakah anda akan "+ket,
       text:"Apakah anda yakin ?",
       type:"warning",
       showCancelButton: true,
       confirmButtonColor: "#DD6B55",
       confirmButtonText: "Saya yakin!",
       cancelButtonText: "Batal!",
       closeOnConfirm: true
     },
     function(){
       $.post('<?php echo e(route('approveFile')); ?>',{id_item_permohonan:id_item_permohonan,doc_status:doc_status, catatan:catatan}).done(function(data){
         if(data.status == 'success'){
           <?php if(Auth::getUser()->level==1): ?>
           var st_pakai = data.file_doc.acc_admin;
           <?php elseif(Auth::getUser()->level==2): ?>
           var st_pakai = data.file_doc.acc_kasi;
           <?php elseif(Auth::getUser()->level==4): ?>
           var st_pakai = data.file_doc.acc_kabid;
           <?php elseif(Auth::getUser()->level==5): ?>
           var st_pakai = data.file_doc.acc_kadin;
           <?php else: ?>
           var st_pakai = '';
           <?php endif; ?>
          if (st_pakai == 'Terima') {
            var hsl = '<a href="javascript:void(0)" class="btn btn-info"><i class="fa fa-check"><span> Dokumen sudah Diterima</span></i></a>';
          }else{
            var hsl = '<a href="javascript:void(0)" class="btn btn-danger"><i class="fa fa-times"><span> Dokumen Ditolak</span></i></a>';
          }
          $('.panel-btn-waiting'+id_item_permohonan).html(hsl);
          // $('#detail-dialog').modal('hide');

          // filePendukung(data.id_item_permohonan);
           // datagrid.reload();
           console.log(data.content)
          // $('#detail-dialog').html(data.content);
           swal("Success!", "Data Berhasil Di "+st_pakai+" !", "success");
          // $('.second-modal').html(data.content);
         }else if(data.status=='fail'){
           // datagrid.reload();
           swal("Maaf!", "Anda bukan pemilik berita ini !", "error");
         }else{
           // datagrid.reload();
           swal("Maaf!", "Berita telah dihapus sebelum ini !", "error");
         }
       });
     });
    }

</script>
